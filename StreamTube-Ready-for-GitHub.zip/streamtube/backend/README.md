
# StreamTube Backend - Telegram Channel Video Streaming

Production-ready TypeScript + Express + PostgreSQL backend for streaming videos synced from Telegram channels.

## Critical Telegram API Truth

- **Bot API CANNOT fetch history.** `getUpdates`/webhook only receives *new* messages from now onward, and `getFile` only works if you already know `file_id` from a recent update. There is no `getChannelHistory` in Bot API.
- **History sync REQUIRES MTProto:** You must use `api_id` + `api_hash` (from https://my.telegram.org) + a **user session** (`StringSession` from gramjs). The user must be a member/admin of the channel.
- Bot API file size limit: 20MB download. MTProto allows up to 2GB (4GB premium) - essential for video.

This backend implements both:
- `botClient.ts` -> `getChat`, `getFile`, `downloadStream`, `getUpdates` (real-time new posts)
- `mtprotoClient.ts` -> `fetchChannelHistory` filtered for `video/*` with FloodWait handling, normalized metadata

## Architecture

```
/src
  /config   env (zod), database (pg Pool)
  /db
    /migrations 001_initial (15 tables) + 002_seed_categories
    migrate.ts runner
  /modules
    /telegram
      botClient.ts
      mtprotoClient.ts (telegram lib StringSession)
      syncService.ts (dup check by telegram_message_id, storage save, job logs)
      storageAdapter.ts (interface + Local + S3 + factory)
    /videos  service, controller, routes with Range support
    /auth    session auth (express-session + connect-pg-simple + bcrypt)
    /admin   telegram test/sync/status/logs, video patch/delete, categories
  /middleware auth, admin, rateLimit, validate, errorHandler
  /routes index.ts
  app.ts (helmet, cors, cookies, session)
  server.ts
```

## 15 Tables

users, video_categories, telegram_channels, videos, telegram_sync_jobs, video_views, watch_history, watch_later, video_likes, comments, subscriptions, playlists, playlist_videos, video_reports, admin_users + user_sessions for connect-pg-simple.

All have indexes, foreign keys, updated_at triggers.

## Endpoints

- `GET /api/videos?search=&category=&channel=&sort=latest|popular&page=&limit=` 
- `GET /api/videos/:id` (supports uuid or slug)
- `GET /api/videos/:id/related`
- `GET /api/videos/:id/stream` **Range supported** (206 Partial Content), streams from storage or proxies telegram file url, rate limited per IP+video
- `POST /api/videos/:id/views` { progress? }
- `POST /api/auth/register, /login, /logout, GET /me`
- `GET /api/categories` public
- `GET/POST /api/admin/...` (requires admin_users row) : test-bot, test-mtproto, telegram/sync (trigger), status, logs/:id, channels, videos patch/delete, categories CRUD, admins, stats

## Setup

```bash
cp .env.example .env
npm install
npm run migrate
npm run dev
```

Create admin: insert into users then admin_users.

```sql
INSERT INTO users (username,email,password_hash) VALUES ('admin','admin@example.com', crypt('password', gen_salt('bf')));
-- then hash with bcrypt in app, or use register endpoint then:
INSERT INTO admin_users (user_id, role) VALUES ('<user-id>','super_admin');
```

## Streaming Details

- Parses `Range: bytes=start-end`
- Returns 206 with `Content-Range`, `Accept-Ranges`, `Content-Length`
- LocalStorageAdapter streams via `fs.createReadStream({start,end})`
- S3 via `GetObjectCommand` (future: add Range header to S3 request - currently streams full then slices; for production use `Range` in S3 command)
- Telegram fallback: if `storage_type=telegram`, fetches file_url and proxies with Range passthrough
- Visibility check: private videos require session

## Env - .env.example full list

See .env.example file.

## Storage

- `STORAGE_TYPE=local` -> `LOCAL_STORAGE_PATH=./uploads`, served at `/static` and streamed via `/stream` endpoint (stream reads from disk)
- `STORAGE_TYPE=s3` -> uses `@aws-sdk/client-s3`, factory `getStorageAdapter()`

## Sync Flow

1. Admin POST `/api/admin/telegram/sync` { channelId, limit }
2. SyncService creates `telegram_sync_jobs` row status=running
3. MtProto fetch history, filtered `video/*`
4. Dup check `SELECT id FROM videos WHERE channel_telegram_id=$1 AND telegram_message_id=$2`
5. Insert video pending, download via MTProto `client.downloadMedia`
6. Save via StorageAdapter, mark ready
7. Job completed with counters

All files are real production code, no mocks.
