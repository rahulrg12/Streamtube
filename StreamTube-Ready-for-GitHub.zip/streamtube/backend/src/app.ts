import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "path";

dotenv.config({ path: path.join(__dirname, "../.env") });
dotenv.config();

import authRoutes from "./routes/auth";
import videoRoutes from "./routes/videos";
import channelRoutes from "./routes/channels";
import adminRoutes from "./routes/admin";
import { errorHandler } from "./middleware/error";

const app = express();

app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:5173",
  credentials: true,
  exposedHeaders: ["Content-Range", "Accept-Ranges", "Content-Length"]
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Rate limiting
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/", generalLimiter);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: "Too many requests, try later" }
});

// Routes
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    uptime: process.uptime(),
    version: "1.0.0",
    database: "connected",
    telegram_bot: process.env.TELEGRAM_BOT_TOKEN ? "configured" : "not_configured",
    mtproto: process.env.SESSION_STRING ? "configured" : "not_configured",
    storage: process.env.STORAGE_TYPE || "telegram"
  });
});

app.use("/api/auth", authLimiter, authRoutes);
app.use("/api/videos", videoRoutes);
app.use("/api/channels", channelRoutes);
app.use("/api/admin", adminRoutes);

app.use(errorHandler);

export default app;
