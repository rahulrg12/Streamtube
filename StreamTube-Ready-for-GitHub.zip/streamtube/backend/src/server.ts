
import { createApp } from './app';
import { env } from './config/env';
import { pool } from './config/database';

async function main() {
  const app = createApp();

  // check DB connection before starting
  try {
    await pool.query('SELECT 1');
    console.log('✅ Database connected');
  } catch (e: any) {
    console.error('❌ Database connection failed:', e.message);
    console.error('   DATABASE_URL:', env.DATABASE_URL.replace(/:[^@]+@/, ':****@'));
    process.exit(1);
  }

  const server = app.listen(env.PORT, () => {
    console.log(`🚀 StreamTube backend listening on port ${env.PORT} [${env.NODE_ENV}]`);
    console.log(`   API: http://localhost:${env.PORT}/api`);
    console.log(`   Health: http://localhost:${env.PORT}/api/health`);
    if (env.STORAGE_TYPE === 'local') {
      console.log(`   Static: http://localhost:${env.PORT}/static`);
    }
    if (!env.TELEGRAM_API_ID) {
      console.log('⚠️  TELEGRAM_API_ID not set - MTProto history sync disabled');
      console.log('   Bot API alone CANNOT fetch channel history, only new messages');
    }
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('\n🛑 Shutting down...');
    server.close(async () => {
      await pool.end();
      console.log('✅ Shutdown complete');
      process.exit(0);
    });
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
