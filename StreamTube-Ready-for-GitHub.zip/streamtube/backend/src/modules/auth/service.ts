
import bcrypt from 'bcrypt';
import { pool } from '../../config/database';

export interface RegisterInput {
  username: string;
  email: string;
  password: string;
  display_name?: string;
}

export class AuthService {
  async findUserByEmail(email: string) {
    const res = await pool.query('SELECT * FROM users WHERE email = $1 LIMIT 1', [email.toLowerCase()]);
    return res.rows[0] || null;
  }

  async findUserByUsername(username: string) {
    const res = await pool.query('SELECT * FROM users WHERE username = $1 LIMIT 1', [username]);
    return res.rows[0] || null;
  }

  async findUserById(id: string) {
    const res = await pool.query('SELECT id, username, email, display_name, avatar_url, bio, is_verified, created_at FROM users WHERE id=$1', [id]);
    return res.rows[0] || null;
  }

  async register(input: RegisterInput) {
    const existingEmail = await this.findUserByEmail(input.email);
    if (existingEmail) throw new Error('Email already registered');

    const existingUser = await this.findUserByUsername(input.username);
    if (existingUser) throw new Error('Username taken');

    const hash = await bcrypt.hash(input.password, 12);

    const res = await pool.query(
      `INSERT INTO users (username, email, password_hash, display_name)
       VALUES ($1,$2,$3,$4) RETURNING id, username, email, display_name, avatar_url, created_at`,
      [input.username, input.email.toLowerCase(), hash, input.display_name || input.username]
    );
    return res.rows[0];
  }

  async validateCredentials(emailOrUsername: string, password: string) {
    let user: any = null;
    if (emailOrUsername.includes('@')) {
      const res = await pool.query('SELECT * FROM users WHERE email=$1 LIMIT 1', [emailOrUsername.toLowerCase()]);
      user = res.rows[0];
    } else {
      const res = await pool.query('SELECT * FROM users WHERE username=$1 LIMIT 1', [emailOrUsername]);
      user = res.rows[0];
    }
    if (!user) throw new Error('Invalid credentials');
    if (!user.is_active) throw new Error('Account disabled');

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) throw new Error('Invalid credentials');

    // return safe user
    const { password_hash, ...safe } = user;
    return safe;
  }

  async listUserSessions(userId: string) {
    // not implemented for pg-simple sessions (sess JSON contains user)
    return [];
  }
}

export const authService = new AuthService();
