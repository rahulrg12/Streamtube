
import { Router } from 'express';
import { authController } from './controller';
import { authMiddleware } from '../../middleware/auth';
import { rateLimit } from '../../middleware/rateLimit';

const router = Router();

router.post('/register', rateLimit({ max: 10, windowMs: 60_000 }), authController.register.bind(authController));
router.post('/login', rateLimit({ max: 20, windowMs: 60_000 }), authController.login.bind(authController));
router.post('/logout', authController.logout.bind(authController));
router.get('/me', authMiddleware, authController.me.bind(authController));

export default router;
