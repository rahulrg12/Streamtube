
import { Request, Response, NextFunction } from 'express';
import { authService } from './service';

export class AuthController {
  async register(req: Request, res: Response, next: NextFunction) {
    try {
      const { username, email, password, display_name } = req.body;
      if (!username || !email || !password) {
        return res.status(400).json({ error: 'username, email, password required' });
      }
      if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 chars' });

      const user = await authService.register({ username, email, password, display_name });

      // auto login: set session
      (req as any).session.user = { id: user.id, username: user.username, email: user.email };

      res.status(201).json({ data: user });
    } catch (e: any) {
      if (e.message.includes('already') || e.message.includes('taken')) {
        return res.status(409).json({ error: e.message });
      }
      next(e);
    }
  }

  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, username, password } = req.body;
      const identifier = email || username;
      if (!identifier || !password) return res.status(400).json({ error: 'identifier and password required' });

      const user = await authService.validateCredentials(identifier, password);

      (req as any).session.user = { id: user.id, username: user.username, email: user.email };
      // regenerate to prevent fixation
      await new Promise<void>((resolve, reject) => {
        (req as any).session.save((err: any) => err ? reject(err) : resolve());
      });

      res.json({ data: { id: user.id, username: user.username, email: user.email, display_name: user.display_name, avatar_url: user.avatar_url } });
    } catch (e: any) {
      if (e.message.includes('Invalid') || e.message.includes('disabled')) {
        return res.status(401).json({ error: e.message });
      }
      next(e);
    }
  }

  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      (req as any).session.destroy((err: any) => {
        if (err) return next(err);
        res.clearCookie('connect.sid');
        res.json({ success: true });
      });
    } catch (e) {
      next(e);
    }
  }

  async me(req: Request, res: Response, next: NextFunction) {
    try {
      const sessionUser = (req as any).session?.user;
      if (!sessionUser) return res.status(401).json({ error: 'Not authenticated' });

      const user = await authService.findUserById(sessionUser.id);
      if (!user) return res.status(401).json({ error: 'User not found' });

      res.json({ data: user });
    } catch (e) {
      next(e);
    }
  }
}

export const authController = new AuthController();
