
import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { videoService } from './service';
import { pool } from '../../config/database';
import { getStorageAdapter } from '../telegram/storageAdapter';
import { botClient } from '../telegram/botClient';

export class VideoController {
  async list(req: Request, res: Response, next: NextFunction) {
    try {
      const query = {
        page: parseInt(req.query.page as string) || 1,
        limit: parseInt(req.query.limit as string) || 20,
        search: req.query.search as string,
        category: req.query.category as string,
        channel: req.query.channel as string,
        sort: (req.query.sort as any) || 'latest',
        status: (req.query.status as any),
        visibility: (req.query.visibility as any),
        duration: (req.query.duration as any),
        is_featured: req.query.is_featured ? req.query.is_featured === 'true' : undefined,
      };
      const result = await videoService.list(query);
      res.json(result);
    } catch (e) {
      next(e);
    }
  }

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const video = await videoService.getById(req.params.id);
      if (!video) return res.status(404).json({ error: 'Video not found' });

      if (video.visibility === 'private') {
        // allow only if owner or admin - check session
        const user = (req as any).session?.user;
        if (!user) return res.status(403).json({ error: 'Private video' });
        // optionally check admin
        if (video.uploaded_by !== user.id) {
          const adminCheck = await pool.query('SELECT 1 FROM admin_users WHERE user_id=$1 AND is_active=true', [user.id]);
          if (adminCheck.rows.length === 0) return res.status(403).json({ error: 'Private video' });
        }
      }

      if (video.status !== 'ready' && video.visibility !== 'private') {
        // only admin can view non-ready
        const user = (req as any).session?.user;
        if (!user) return res.status(404).json({ error: 'Video not ready' });
      }

      res.json({ data: video });
    } catch (e) {
      next(e);
    }
  }

  async getRelated(req: Request, res: Response, next: NextFunction) {
    try {
      const related = await videoService.getRelated(req.params.id, parseInt(req.query.limit as string) || 12);
      res.json({ data: related });
    } catch (e) {
      next(e);
    }
  }

  async recordView(req: Request, res: Response, next: NextFunction) {
    try {
      const video = await videoService.getById(req.params.id);
      if (!video) return res.status(404).json({ error: 'Video not found' });

      const userId = (req as any).session?.user?.id;
      const ip = req.ip || req.socket.remoteAddress || '';
      const ipHash = crypto.createHash('sha256').update(ip).digest('hex').substring(0, 32);
      const ua = req.headers['user-agent'] || '';

      await videoService.incrementView(video.id, userId, ipHash, ua);

      // also upsert watch_history if logged in and progress provided
      if (userId && req.body?.progress) {
        await pool.query(
          `INSERT INTO watch_history (user_id, video_id, progress, last_watched_at)
           VALUES ($1,$2,$3,NOW())
           ON CONFLICT (user_id, video_id) DO UPDATE SET progress=$3, last_watched_at=NOW(), updated_at=NOW()`,
          [userId, video.id, req.body.progress]
        );
      }

      res.json({ success: true });
    } catch (e) {
      next(e);
    }
  }

  /**
   * Streaming endpoint with Range support
   * Supports:
   * - local files via fs streams
   * - S3 via streaming
   * - Telegram fallback (proxy via bot file url if still telegram-stored)
   */
  async stream(req: Request, res: Response, next: NextFunction) {
    try {
      const video = await videoService.getById(req.params.id);
      if (!video) return res.status(404).json({ error: 'Video not found' });

      if (video.visibility === 'private') {
        const user = (req as any).session?.user;
        if (!user) return res.status(403).json({ error: 'Private video requires login' });
      }

      if (video.status !== 'ready') {
        return res.status(404).json({ error: `Video not ready (status=${video.status})` });
      }

      const storage = getStorageAdapter();

      // Telegram storage fallback: if storage_type == telegram and we have file_id
      if (video.storage_type === 'telegram' && video.telegram_file_id) {
        try {
          const file = await botClient.getFile(video.telegram_file_id);
          if (!file.file_path) throw new Error('No file_path');
          // Redirect to telegram file url (temporary, but works)
          const fileUrl = botClient.getFileUrl(file.file_path);
          // Proxy streaming with range? Simplest: redirect
          // For Range support we proxy via fetch with range header
          const range = req.headers.range;
          const fetchHeaders: any = {};
          if (range) fetchHeaders['Range'] = range;

          const fetch = (await import('node-fetch')).default as any;
          const tRes = await fetch(fileUrl, { headers: fetchHeaders });

          if (!tRes.ok && tRes.status !== 206) {
            throw new Error(`Telegram file fetch failed ${tRes.status}`);
          }

          // copy headers
          res.status(tRes.status);
          const ct = tRes.headers.get('content-type') || video.mime_type || 'video/mp4';
          res.setHeader('Content-Type', ct);
          const contentLength = tRes.headers.get('content-length');
          if (contentLength) res.setHeader('Content-Length', contentLength);
          const contentRange = tRes.headers.get('content-range');
          if (contentRange) res.setHeader('Content-Range', contentRange);
          res.setHeader('Accept-Ranges', 'bytes');

          tRes.body.pipe(res);
          return;
        } catch (e: any) {
          console.error('Telegram proxy stream failed, falling back to storage if any', e.message);
          // fall through to storage attempt
        }
      }

      if (!video.storage_key) {
        return res.status(404).json({ error: 'Video file not found in storage' });
      }

      const exists = await storage.exists(video.storage_key);
      if (!exists) return res.status(404).json({ error: 'Storage file missing' });

      const fileSize = video.file_size || (storage.getSize ? await storage.getSize(video.storage_key) : undefined);

      const range = req.headers.range;

      // If no range and we have method to get URL for S3, we could redirect? But we want to support range ourselves.
      const contentType = video.mime_type || 'video/mp4';

      if (range && fileSize) {
        // Parse Range: bytes=0-1023, bytes=500-
        const parts = range.replace(/bytes=/, '').split('-');
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

        if (isNaN(start) || isNaN(end) || start >= fileSize || end >= fileSize) {
          res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end();
          return;
        }

        const chunkSize = end - start + 1;

        res.writeHead(206, {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunkSize,
          'Content-Type': contentType,
          'Cache-Control': 'public, max-age=3600',
        });

        // For local adapter we need to create stream with start/end; our interface doesn't expose range yet,
        // so for local we handle manually with fs, for S3 we also handle but our adapter returns full stream.
        // We'll attempt to get ranged stream:
        if ((storage as any).getRangeStream) {
          const stream = await (storage as any).getRangeStream(video.storage_key, start, end);
          stream.pipe(res);
        } else {
          // fallback: get full stream and skip? Better: for local use fs.createReadStream with range
          // Detect LocalStorageAdapter by trying to read with fs directly if possible
          // We'll re-implement local range using adapter's underlying file if available
          try {
            const stream = await storage.getStream(video.storage_key);
            // If it's a fs ReadStream, we can't easily seek; simplest: pipe but we already sent 206 headers,
            // client expects chunk. For proper range we need fs slice.
            // We will attempt to if storage is Local: use fs directly
            if ((storage as any).basePath !== undefined || video.storage_key.includes('/')) {
              const fs = await import('fs');
              const path = await import('path');
              const { env } = await import('../../config/env');
              const fullPath = path.join(env.LOCAL_STORAGE_PATH, video.storage_key);
              const fsStream = fs.createReadStream(fullPath, { start, end });
              fsStream.pipe(res);
              fsStream.on('error', (err) => {
                console.error('Stream error', err);
                if (!res.headersSent) res.status(500).end();
                else res.end();
              });
              return;
            } else {
              // S3 fallback: just pipe whole (not ideal) but better than nothing
              stream.pipe(res);
            }
          } catch (err) {
            throw err;
          }
        }
      } else {
        // No range - full file
        res.writeHead(200, {
          'Content-Length': fileSize || undefined,
          'Content-Type': contentType,
          'Accept-Ranges': 'bytes',
          'Cache-Control': 'public, max-age=3600',
        });
        const stream = await storage.getStream(video.storage_key);
        stream.pipe(res);
        stream.on('error', (err) => {
          console.error('Stream error', err);
          if (!res.headersSent) res.status(500).end();
          else res.end();
        });
      }
    } catch (e) {
      next(e);
    }
  }
}

export const videoController = new VideoController();
