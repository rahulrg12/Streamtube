
import { pool } from '../../config/database';

export interface VideoListQuery {
  page?: number;
  limit?: number;
  search?: string;
  category?: string; // slug or id
  channel?: string; // channel uuid or telegram id
  sort?: 'latest' | 'popular' | 'oldest' | 'views' | 'duration';
  status?: 'ready' | 'pending' | 'processing';
  visibility?: 'public' | 'unlisted' | 'private';
  duration?: 'short' | 'medium' | 'long'; // <4min, 4-20, >20
  is_featured?: boolean;
}

export interface PaginatedVideos {
  data: any[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

export class VideoService {
  async list(query: VideoListQuery): Promise<PaginatedVideos> {
    const page = Math.max(1, query.page || 1);
    const limit = Math.min(100, Math.max(1, query.limit || 20));
    const offset = (page - 1) * limit;

    let where = `WHERE v.deleted_at IS NULL AND v.status = COALESCE($1, v.status) AND v.visibility = COALESCE($2, v.visibility)`;
    const params: any[] = [];
    let idx = 3;

    params.push(query.status || 'ready');
    params.unshift(query.visibility || 'public'); // now $1=visibility, $2=status after rework? Let's fix ordering.
    // Actually rework: we used $1 for status, $2 for visibility; so params[0]=status, params[1]=visibility
    // Fix: reconstruct
    // Let's rebuild cleaner
    const conditions: string[] = ['v.deleted_at IS NULL'];
    const values: any[] = [];
    let p = 1;

    if (query.status) {
      conditions.push(`v.status = $${p++}`);
      values.push(query.status);
    } else {
      conditions.push(`v.status = $${p++}`);
      values.push('ready');
    }

    if (query.visibility) {
      conditions.push(`v.visibility = $${p++}`);
      values.push(query.visibility);
    } else {
      conditions.push(`v.visibility = $${p++}`);
      values.push('public');
    }

    if (query.search) {
      conditions.push(`(v.title ILIKE $${p} OR v.description ILIKE $${p})`);
      values.push(`%${query.search}%`);
      p++;
    }

    if (query.category) {
      // category can be slug or uuid
      if (query.category.match(/^[0-9a-fA-F-]{36}$/)) {
        conditions.push(`v.category_id = $${p++}`);
        values.push(query.category);
      } else {
        conditions.push(`vc.slug = $${p++}`);
        values.push(query.category);
      }
    }

    if (query.channel) {
      if (query.channel.match(/^[0-9a-fA-F-]{36}$/)) {
        conditions.push(`v.channel_id = $${p++}`);
        values.push(query.channel);
      } else {
        // try numeric telegram id
        const num = Number(query.channel);
        if (!isNaN(num)) {
          conditions.push(`v.channel_telegram_id = $${p++}`);
          values.push(num);
        } else {
          conditions.push(`tc.username = $${p++}`);
          values.push(query.channel);
        }
      }
    }

    if (query.is_featured !== undefined) {
      conditions.push(`v.is_featured = $${p++}`);
      values.push(query.is_featured);
    }

    if (query.duration) {
      if (query.duration === 'short') conditions.push(`v.duration < 240`);
      if (query.duration === 'medium') conditions.push(`v.duration >= 240 AND v.duration <= 1200`);
      if (query.duration === 'long') conditions.push(`v.duration > 1200`);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    let orderBy = 'v.created_at DESC';
    switch (query.sort) {
      case 'popular':
      case 'views':
        orderBy = 'v.view_count DESC, v.created_at DESC';
        break;
      case 'oldest':
        orderBy = 'v.created_at ASC';
        break;
      case 'duration':
        orderBy = 'v.duration DESC';
        break;
      case 'latest':
      default:
        orderBy = 'v.created_at DESC';
    }

    const countQuery = `
      SELECT COUNT(*) as total
      FROM videos v
      LEFT JOIN video_categories vc ON v.category_id = vc.id
      LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
      ${whereClause}
    `;
    const countRes = await pool.query(countQuery, values);
    const total = parseInt(countRes.rows[0].total, 10);

    const dataQuery = `
      SELECT
        v.id, v.title, v.description, v.slug, v.duration, v.width, v.height,
        v.mime_type, v.thumbnail_url, v.storage_url, v.view_count, v.like_count,
        v.created_at, v.is_featured, v.file_size, v.category_id,
        vc.name as category_name, vc.slug as category_slug,
        tc.title as channel_title, tc.username as channel_username, tc.channel_id as channel_telegram_id,
        v.channel_id
      FROM videos v
      LEFT JOIN video_categories vc ON v.category_id = vc.id
      LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
      ${whereClause}
      ORDER BY ${orderBy}
      LIMIT $${p++} OFFSET $${p++}
    `;

    const dataValues = [...values, limit, offset];
    const dataRes = await pool.query(dataQuery, dataValues);

    return {
      data: dataRes.rows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  async getById(id: string) {
    // id can be uuid or slug
    let q: string;
    let params: any[];
    if (id.match(/^[0-9a-fA-F-]{36}$/)) {
      q = `
        SELECT v.*, vc.name as category_name, vc.slug as category_slug,
               tc.title as channel_title, tc.username as channel_username, tc.channel_id as channel_telegram_id
        FROM videos v
        LEFT JOIN video_categories vc ON v.category_id = vc.id
        LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
        WHERE v.id = $1 AND v.deleted_at IS NULL
      `;
      params = [id];
    } else {
      q = `
        SELECT v.*, vc.name as category_name, vc.slug as category_slug,
               tc.title as channel_title, tc.username as channel_username, tc.channel_id as channel_telegram_id
        FROM videos v
        LEFT JOIN video_categories vc ON v.category_id = vc.id
        LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
        WHERE v.slug = $1 AND v.deleted_at IS NULL
      `;
      params = [id];
    }
    const res = await pool.query(q, params);
    return res.rows[0] || null;
  }

  async getRelated(videoId: string, limit = 12) {
    const video = await this.getById(videoId);
    if (!video) return [];

    const res = await pool.query(
      `
      SELECT v.id, v.title, v.slug, v.duration, v.thumbnail_url, v.view_count, v.created_at,
             vc.name as category_name, tc.title as channel_title
      FROM videos v
      LEFT JOIN video_categories vc ON v.category_id = vc.id
      LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
      WHERE v.id != $1
        AND v.deleted_at IS NULL
        AND v.status = 'ready'
        AND v.visibility = 'public'
        AND (v.category_id = $2 OR v.channel_id = $3)
      ORDER BY v.view_count DESC, v.created_at DESC
      LIMIT $4
      `,
      [video.id, video.category_id, video.channel_id, limit]
    );

    if (res.rows.length < limit) {
      const more = await pool.query(
        `
        SELECT v.id, v.title, v.slug, v.duration, v.thumbnail_url, v.view_count, v.created_at,
               vc.name as category_name, tc.title as channel_title
        FROM videos v
        LEFT JOIN video_categories vc ON v.category_id = vc.id
        LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
        WHERE v.id != $1 AND v.deleted_at IS NULL AND v.status='ready' AND v.visibility='public'
        ORDER BY RANDOM()
        LIMIT $2
        `,
        [video.id, limit - res.rows.length]
      );
      return [...res.rows, ...more.rows];
    }

    return res.rows;
  }

  async incrementView(videoId: string, userId?: string, ipHash?: string, userAgent?: string) {
    // insert view row
    await pool.query(
      `INSERT INTO video_views (video_id, user_id, ip_hash, user_agent) VALUES ($1,$2,$3,$4)`,
      [videoId, userId || null, ipHash || null, userAgent || null]
    );
    // increment counter
    await pool.query(`UPDATE videos SET view_count = view_count + 1 WHERE id = $1`, [videoId]);
  }

  async updateVideo(id: string, patch: any) {
    const allowed = ['title', 'description', 'category_id', 'visibility', 'status', 'is_featured'];
    const keys = Object.keys(patch).filter(k => allowed.includes(k));
    if (keys.length === 0) throw new Error('No valid fields to update');

    const setClauses = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
    const values = [id, ...keys.map(k => patch[k])];

    const res = await pool.query(
      `UPDATE videos SET ${setClauses}, updated_at=NOW() WHERE id=$1 AND deleted_at IS NULL RETURNING *`,
      values
    );
    return res.rows[0] || null;
  }

  async softDelete(id: string) {
    const res = await pool.query(
      `UPDATE videos SET deleted_at=NOW(), status='deleted', updated_at=NOW() WHERE id=$1 AND deleted_at IS NULL RETURNING id`,
      [id]
    );
    return res.rows.length > 0;
  }
}

export const videoService = new VideoService();
