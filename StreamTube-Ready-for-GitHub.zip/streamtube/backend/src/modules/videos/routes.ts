
import { Router } from 'express';
import { videoController } from './controller';
import { streamRateLimiter } from '../../middleware/rateLimit';

const router = Router();

// Public
router.get('/', videoController.list.bind(videoController));
router.get('/:id/related', videoController.getRelated.bind(videoController));
router.get('/:id/stream', streamRateLimiter, videoController.stream.bind(videoController));
router.post('/:id/views', videoController.recordView.bind(videoController));
router.get('/:id', videoController.getById.bind(videoController));

export default router;
