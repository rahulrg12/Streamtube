
import { Router } from 'express';
import { adminController } from './controller';
import { authMiddleware } from '../../middleware/auth';
import { adminMiddleware } from '../../middleware/admin';

const router = Router();

// all admin routes require auth + admin role
router.use(authMiddleware, adminMiddleware);

router.get('/stats', adminController.stats.bind(adminController));

// telegram
router.get('/telegram/test-bot', adminController.testTelegramBot.bind(adminController));
router.get('/telegram/test-mtproto', adminController.testMtProto.bind(adminController));
router.post('/telegram/sync', adminController.triggerSync.bind(adminController));
router.get('/telegram/status', adminController.syncStatus.bind(adminController));
router.get('/telegram/logs/:id', adminController.syncLogs.bind(adminController));
router.get('/telegram/channels', adminController.listChannels.bind(adminController));

// videos
router.patch('/videos/:id', adminController.patchVideo.bind(adminController));
router.delete('/videos/:id', adminController.deleteVideo.bind(adminController));

// categories
router.get('/categories', adminController.listCategories.bind(adminController));
router.post('/categories', adminController.createCategory.bind(adminController));
router.patch('/categories/:id', adminController.updateCategory.bind(adminController));
router.delete('/categories/:id', adminController.deleteCategory.bind(adminController));

// admin users
router.get('/admins', adminController.listAdmins.bind(adminController));

export default router;
