
import { Request, Response, NextFunction } from 'express';
import { pool } from '../../config/database';
import { botClient } from '../telegram/botClient';
import { mtprotoClient } from '../telegram/mtprotoClient';
import { telegramSyncService } from '../telegram/syncService';
import { videoService } from '../videos/service';

export class AdminController {
  // Telegram

  async testTelegramBot(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await botClient.testConnection();
      if (!result.ok) return res.status(400).json({ ok: false, error: result.error });
      // Also try getChat if CHANNEL_ID provided
      let chat = null;
      const channelId = req.query.channelId as string || process.env.TELEGRAM_CHANNEL_ID;
      if (channelId) {
        try {
          chat = await botClient.getChat(channelId);
        } catch (e: any) {
          chat = { error: e.message };
        }
      }
      res.json({ ok: true, bot: result.botInfo, chat });
    } catch (e) { next(e); }
  }

  async testMtProto(req: Request, res: Response, next: NextFunction) {
    try {
      const client = await mtprotoClient.connect();
      const me = await client.getMe();
      await mtprotoClient.disconnect().catch(()=>{});
      res.json({ ok: true, me: { id: (me as any).id, username: (me as any).username, firstName: (me as any).firstName } });
    } catch (e: any) {
      res.status(400).json({ ok: false, error: e.message, hint: 'Ensure API_ID, API_HASH, SESSION_STRING are valid user session (not bot token)' });
    }
  }

  async triggerSync(req: Request, res: Response, next: NextFunction) {
    try {
      const { channelId, limit, offsetId } = req.body;
      const targetChannel = channelId || process.env.TELEGRAM_CHANNEL_ID;
      if (!targetChannel) return res.status(400).json({ error: 'channelId required (telegram channel id e.g. -100123...)' });

      const userId = (req as any).session?.user?.id;

      // Run async but respond immediately with job id? For simplicity we run synchronously with timeout.
      // In production use a queue (BullMQ).
      res.json({ accepted: true, message: 'Sync started, check logs endpoint for progress' });

      // Fire and forget after response? Use setImmediate to allow response to finish
      setImmediate(async () => {
        try {
          await telegramSyncService.syncChannel({
            channelTelegramId: targetChannel,
            limit: limit || 50,
            offsetId: offsetId || undefined,
            createdBy: userId,
          });
        } catch (err: any) {
          console.error('Background sync failed', err);
        }
      });

    } catch (e) { next(e); }
  }

  async syncStatus(req: Request, res: Response, next: NextFunction) {
    try {
      const resJobs = await pool.query(
        `SELECT j.*, tc.title as channel_title FROM telegram_sync_jobs j LEFT JOIN telegram_channels tc ON j.channel_id=tc.id ORDER BY j.created_at DESC LIMIT 50`
      );
      res.json({ data: resJobs.rows });
    } catch (e) { next(e); }
  }

  async syncLogs(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const r = await pool.query(`SELECT * FROM telegram_sync_jobs WHERE id=$1`, [id]);
      if (!r.rows[0]) return res.status(404).json({ error: 'Job not found' });
      res.json({ data: r.rows[0] });
    } catch (e) { next(e); }
  }

  async listChannels(req: Request, res: Response, next: NextFunction) {
    try {
      const r = await pool.query(`SELECT * FROM telegram_channels ORDER BY created_at DESC`);
      res.json({ data: r.rows });
    } catch (e) { next(e); }
  }

  // Video admin

  async patchVideo(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const patch = req.body;
      const updated = await videoService.updateVideo(id, patch);
      if (!updated) return res.status(404).json({ error: 'Video not found' });
      res.json({ data: updated });
    } catch (e) { next(e); }
  }

  async deleteVideo(req: Request, res: Response, next: NextFunction) {
    try {
      const ok = await videoService.softDelete(req.params.id);
      if (!ok) return res.status(404).json({ error: 'Video not found or already deleted' });
      res.json({ success: true });
    } catch (e) { next(e); }
  }

  // Categories

  async listCategories(req: Request, res: Response, next: NextFunction) {
    try {
      const r = await pool.query(`SELECT * FROM video_categories ORDER BY name ASC`);
      res.json({ data: r.rows });
    } catch (e) { next(e); }
  }

  async createCategory(req: Request, res: Response, next: NextFunction) {
    try {
      const { name, slug, description, icon } = req.body;
      if (!name || !slug) return res.status(400).json({ error: 'name and slug required' });
      const r = await pool.query(
        `INSERT INTO video_categories (name, slug, description, icon) VALUES ($1,$2,$3,$4) RETURNING *`,
        [name, slug, description || null, icon || null]
      );
      res.status(201).json({ data: r.rows[0] });
    } catch (e: any) {
      if (e.code === '23505') return res.status(409).json({ error: 'slug or name already exists' });
      next(e);
    }
  }

  async updateCategory(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { name, slug, description, icon } = req.body;
      const r = await pool.query(
        `UPDATE video_categories SET name=COALESCE($2,name), slug=COALESCE($3,slug), description=COALESCE($4,description), icon=COALESCE($5,icon), updated_at=NOW() WHERE id=$1 RETURNING *`,
        [id, name || null, slug || null, description || null, icon || null]
      );
      if (!r.rows[0]) return res.status(404).json({ error: 'Category not found' });
      res.json({ data: r.rows[0] });
    } catch (e) { next(e); }
  }

  async deleteCategory(req: Request, res: Response, next: NextFunction) {
    try {
      await pool.query(`DELETE FROM video_categories WHERE id=$1`, [req.params.id]);
      res.json({ success: true });
    } catch (e) { next(e); }
  }

  // Admin users

  async listAdmins(req: Request, res: Response, next: NextFunction) {
    try {
      const r = await pool.query(`
        SELECT au.*, u.username, u.email FROM admin_users au JOIN users u ON au.user_id=u.id ORDER BY au.created_at DESC
      `);
      res.json({ data: r.rows });
    } catch (e) { next(e); }
  }

  // Dashboard stats
  async stats(req: Request, res: Response, next: NextFunction) {
    try {
      const [videos, users, views, jobs] = await Promise.all([
        pool.query(`SELECT COUNT(*) as c, COUNT(*) FILTER (WHERE status='ready') as ready FROM videos WHERE deleted_at IS NULL`),
        pool.query(`SELECT COUNT(*) as c FROM users`),
        pool.query(`SELECT COUNT(*) as c FROM video_views WHERE created_at > NOW() - INTERVAL '7 days'`),
        pool.query(`SELECT COUNT(*) as c FROM telegram_sync_jobs WHERE created_at > NOW() - INTERVAL '7 days'`),
      ]);
      res.json({
        data: {
          videos_total: parseInt(videos.rows[0].c),
          videos_ready: parseInt(videos.rows[0].ready),
          users_total: parseInt(users.rows[0].c),
          views_last_7d: parseInt(views.rows[0].c),
          sync_jobs_last_7d: parseInt(jobs.rows[0].c),
        }
      });
    } catch (e) { next(e); }
  }
}

export const adminController = new AdminController();
