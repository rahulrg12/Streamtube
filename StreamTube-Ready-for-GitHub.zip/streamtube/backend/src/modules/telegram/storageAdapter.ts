
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { S3Client, GetObjectCommand, PutObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { env } from '../../config/env';

export interface StorageAdapter {
  save(key: string, stream: Readable | Buffer, contentType?: string): Promise<string>;
  getStream(key: string): Promise<Readable>;
  exists(key: string): Promise<boolean>;
  getUrl?(key: string): Promise<string> | string;
  getSize?(key: string): Promise<number>;
  delete?(key: string): Promise<void>;
}

export class LocalStorageAdapter implements StorageAdapter {
  private basePath: string;
  private baseUrl?: string;

  constructor(basePath?: string, baseUrl?: string) {
    this.basePath = basePath || env.LOCAL_STORAGE_PATH;
    this.baseUrl = baseUrl || env.LOCAL_STORAGE_BASE_URL;
    // ensure directory exists
    if (!fs.existsSync(this.basePath)) {
      fs.mkdirSync(this.basePath, { recursive: true });
    }
  }

  private resolveKey(key: string): string {
    // prevent directory traversal
    const normalized = path.normalize(key).replace(/^(\.\.[\/\\])+/, '');
    return path.join(this.basePath, normalized);
  }

  async save(key: string, stream: Readable | Buffer, contentType?: string): Promise<string> {
    const filePath = this.resolveKey(key);
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    if (Buffer.isBuffer(stream)) {
      await fs.promises.writeFile(filePath, stream);
    } else {
      await new Promise<void>((resolve, reject) => {
        const ws = fs.createWriteStream(filePath);
        (stream as Readable).pipe(ws);
        ws.on('finish', resolve);
        ws.on('error', reject);
        (stream as Readable).on('error', reject);
      });
    }
    // contentType ignored for local but could store metadata file
    return filePath;
  }

  async getStream(key: string): Promise<Readable> {
    const filePath = this.resolveKey(key);
    if (!fs.existsSync(filePath)) throw new Error(`File not found: ${key}`);
    return fs.createReadStream(filePath);
  }

  async exists(key: string): Promise<boolean> {
    return fs.existsSync(this.resolveKey(key));
  }

  async getUrl(key: string): Promise<string> {
    if (this.baseUrl) {
      return `${this.baseUrl.replace(/\/$/, '')}/${key.replace(/^\//, '')}`;
    }
    return this.resolveKey(key);
  }

  async getSize(key: string): Promise<number> {
    const stat = await fs.promises.stat(this.resolveKey(key));
    return stat.size;
  }

  async delete(key: string): Promise<void> {
    const fp = this.resolveKey(key);
    if (fs.existsSync(fp)) await fs.promises.unlink(fp);
  }
}

export class S3StorageAdapter implements StorageAdapter {
  private client: S3Client;
  private bucket: string;

  constructor() {
    if (!env.AWS_S3_BUCKET) throw new Error('AWS_S3_BUCKET required for S3 storage');
    this.bucket = env.AWS_S3_BUCKET;
    this.client = new S3Client({
      region: env.AWS_S3_REGION,
      endpoint: env.AWS_S3_ENDPOINT || undefined,
      forcePathStyle: env.AWS_S3_FORCE_PATH_STYLE,
      credentials: env.AWS_ACCESS_KEY_ID && env.AWS_SECRET_ACCESS_KEY ? {
        accessKeyId: env.AWS_ACCESS_KEY_ID,
        secretAccessKey: env.AWS_SECRET_ACCESS_KEY,
      } : undefined,
    });
  }

  async save(key: string, stream: Readable | Buffer, contentType = 'video/mp4'): Promise<string> {
    const body = Buffer.isBuffer(stream) ? stream : stream;
    const cmd = new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      Body: body as any,
      ContentType: contentType,
    });
    await this.client.send(cmd);
    return `s3://${this.bucket}/${key}`;
  }

  async getStream(key: string): Promise<Readable> {
    const cmd = new GetObjectCommand({ Bucket: this.bucket, Key: key });
    const res = await this.client.send(cmd);
    return res.Body as Readable;
  }

  async exists(key: string): Promise<boolean> {
    try {
      await this.client.send(new HeadObjectCommand({ Bucket: this.bucket, Key: key }));
      return true;
    } catch {
      return false;
    }
  }

  async getUrl(key: string): Promise<string> {
    // If using presigned in production, generate here. For now, return S3 URI.
    // In real production, use @aws-sdk/s3-presigner
    if (env.AWS_S3_ENDPOINT) {
      return `${env.AWS_S3_ENDPOINT.replace(/\/$/, '')}/${this.bucket}/${key}`;
    }
    return `https://${this.bucket}.s3.${env.AWS_S3_REGION}.amazonaws.com/${key}`;
  }

  async getSize(key: string): Promise<number> {
    const head = await this.client.send(new HeadObjectCommand({ Bucket: this.bucket, Key: key }));
    return head.ContentLength || 0;
  }

  async delete(key: string): Promise<void> {
    const { DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}

export function getStorageAdapter(): StorageAdapter {
  if (env.STORAGE_TYPE === 's3') {
    return new S3StorageAdapter();
  }
  return new LocalStorageAdapter();
}

// Singleton for convenience
let singleton: StorageAdapter | null = null;
export function storage(): StorageAdapter {
  if (!singleton) singleton = getStorageAdapter();
  return singleton;
}
