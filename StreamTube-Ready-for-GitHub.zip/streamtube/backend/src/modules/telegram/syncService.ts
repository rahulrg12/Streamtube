
/**
 * Sync Service - orchestrates Telegram -> DB -> Storage
 * Flow:
 * 1. Create sync job log
 * 2. Fetch history via MTProto (video/* only)
 * 3. For each message: check duplication by (channel_telegram_id, telegram_message_id)
 * 4. Insert video row as pending
 * 5. Download file to storage via MTProto or Bot fallback
 * 6. Mark ready, update storage_key/url
 * 7. Finalize job
 */
import { Readable } from 'stream';
import { pool } from '../../config/database';
import { env } from '../../config/env';
import { botClient } from './botClient';
import { mtprotoClient, NormalizedVideoMessage } from './mtprotoClient';
import { getStorageAdapter } from './storageAdapter';

export interface SyncOptions {
  channelTelegramId: string | number;
  limit?: number;
  offsetId?: number;
  createdBy?: string; // user id
}

export interface SyncResult {
  jobId: string;
  messagesScanned: number;
  videosFound: number;
  videosImported: number;
  videosSkipped: number;
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/[\s_]+/g, '-')
    .substring(0, 200);
}

function generateStorageKey(channelId: string, messageId: number, mimeType: string, fileName?: string): string {
  const ext = mimeType.split('/')[1] || (fileName?.split('.').pop() || 'mp4');
  const safeName = fileName ? fileName.replace(/[^a-zA-Z0-9._-]/g, '_') : `video-${messageId}.${ext}`;
  // e.g. telegram/-100123/12345/video.mp4
  return `videos/${channelId}/${messageId}/${safeName}`;
}

export class TelegramSyncService {
  private storage = getStorageAdapter();

  /**
   * Ensure telegram_channels row exists
   */
  private async ensureChannelRow(channelTelegramId: number, title?: string, username?: string): Promise<string> {
    // Try find by channel_id first
    const existing = await pool.query('SELECT id FROM telegram_channels WHERE channel_id = $1', [channelTelegramId]);
    if (existing.rows.length > 0) return existing.rows[0].id;

    // Insert
    const res = await pool.query(
      `INSERT INTO telegram_channels (channel_id, title, username, is_active)
       VALUES ($1,$2,$3,true) RETURNING id`,
      [channelTelegramId, title || `Channel ${channelTelegramId}`, username || null]
    );
    return res.rows[0].id;
  }

  async createSyncJob(channelUuid: string, channelTelegramId: number, jobType = 'history_sync', createdBy?: string): Promise<string> {
    const res = await pool.query(
      `INSERT INTO telegram_sync_jobs (channel_id, channel_telegram_id, status, job_type, started_at, created_by, messages_scanned, videos_found, videos_imported)
       VALUES ($1,$2,'running',$3,NOW(),$4,0,0,0) RETURNING id`,
      [channelUuid, channelTelegramId, jobType, createdBy || null]
    );
    return res.rows[0].id;
  }

  async updateSyncJob(jobId: string, patch: Partial<{
    status: string;
    messages_scanned: number;
    videos_found: number;
    videos_imported: number;
    videos_skipped: number;
    last_offset_id: number;
    error_message: string;
    completed_at: Date;
    logs: any;
  }>) {
    const keys = Object.keys(patch);
    if (keys.length === 0) return;
    const setClauses = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
    const values = [jobId, ...keys.map(k => (patch as any)[k])];
    await pool.query(`UPDATE telegram_sync_jobs SET ${setClauses} WHERE id = $1`, values);
  }

  async syncChannel(options: SyncOptions): Promise<SyncResult> {
    const channelTelegramIdNum = typeof options.channelTelegramId === 'string'
      ? parseInt(options.channelTelegramId as string, 10)
      : options.channelTelegramId;

    console.log(`🔄 Starting sync for ${channelTelegramIdNum} limit=${options.limit || 50}`);

    // Get channel info via MTProto if possible for title
    let title: string | undefined;
    let username: string | undefined;
    try {
      const info = await mtprotoClient.getChannelInfo(options.channelTelegramId);
      title = info.title;
      username = info.username;
    } catch (e: any) {
      console.warn('Could not fetch channel info via MTProto:', e.message);
    }

    const channelUuid = await this.ensureChannelRow(channelTelegramIdNum, title, username);
    const jobId = await this.createSyncJob(channelUuid, channelTelegramIdNum, 'history_sync', options.createdBy);

    let messagesScanned = 0;
    let videosFound = 0;
    let videosImported = 0;
    let videosSkipped = 0;
    let lastOffsetId = options.offsetId || 0;

    try {
      const { messages, totalScanned } = await mtprotoClient.fetchChannelHistory(options.channelTelegramId, {
        limit: options.limit || 50,
        offsetId: options.offsetId,
        filterVideoOnly: true,
      });

      messagesScanned = totalScanned;
      videosFound = messages.length;

      await this.updateSyncJob(jobId, {
        messages_scanned: messagesScanned,
        videos_found: videosFound,
        last_offset_id: lastOffsetId,
      });

      for (const msg of messages) {
        try {
          const isDup = await this.checkDuplicate(channelTelegramIdNum, msg.telegramMessageId);
          if (isDup) {
            videosSkipped++;
            continue;
          }

          // insert video as pending
          const videoId = await this.insertVideoRecord(channelUuid, channelTelegramIdNum, msg);

          // attempt download
          try {
            const storageKey = generateStorageKey(
              channelTelegramIdNum.toString(),
              msg.telegramMessageId,
              msg.mimeType,
              msg.fileName
            );

            // Download via MTProto client (bypasses Bot API 20MB limit)
            // We need entity again
            const client = await mtprotoClient.connect();
            const entity = await client.getEntity(options.channelTelegramId as any);
            // fetch specific message
            const telegramMessages = await client.getMessages(entity as any, { ids: [msg.telegramMessageId] });
            if (!telegramMessages || telegramMessages.length === 0) throw new Error('Message not found for download');

            const buffer = await client.downloadMedia(telegramMessages[0] as any, {}) as Buffer;
            const readable = Readable.from(buffer);

            const savedPath = await this.storage.save(storageKey, readable, msg.mimeType);

            const fileUrl = this.storage.getUrl ? await this.storage.getUrl(storageKey) : savedPath;

            await pool.query(
              `UPDATE videos SET storage_key=$1, storage_url=$2, storage_type=$3, status='ready', updated_at=NOW() WHERE id=$4`,
              [storageKey, fileUrl, env.STORAGE_TYPE, videoId]
            );

            videosImported++;
          } catch (dlErr: any) {
            console.error(`❌ Download failed for message ${msg.telegramMessageId}:`, dlErr.message);
            await pool.query(
              `UPDATE videos SET status='failed', metadata = metadata || $1 WHERE id=$2`,
              [JSON.stringify({ download_error: dlErr.message }), await this.getVideoIdByMessage(channelTelegramIdNum, msg.telegramMessageId) || '00000000-0000-0000-0000-000000000000'],
            ).catch(() => {});
            // mark failed but continue
            await pool.query(`UPDATE videos SET status='failed' WHERE telegram_message_id=$1 AND channel_telegram_id=$2`, [msg.telegramMessageId, channelTelegramIdNum]);
          }
        } catch (innerErr: any) {
          console.error('Inner sync error for message', msg.telegramMessageId, innerErr);
          videosSkipped++;
        }
      }

      await pool.query(
        `UPDATE telegram_channels SET last_synced_at=NOW(), last_message_id=GREATEST(last_message_id, $2) WHERE id=$1`,
        [channelUuid, lastOffsetId || Math.max(0, ...messages.map(m => m.telegramMessageId))]
      );

      await this.updateSyncJob(jobId, {
        status: 'completed',
        messages_scanned: messagesScanned,
        videos_found: videosFound,
        videos_imported: videosImported,
        videos_skipped: videosSkipped,
        completed_at: new Date(),
      });

      await mtprotoClient.disconnect().catch(() => {});

      return { jobId, messagesScanned, videosFound, videosImported, videosSkipped };

    } catch (err: any) {
      await this.updateSyncJob(jobId, {
        status: 'failed',
        error_message: err.message?.substring(0, 2000),
        completed_at: new Date(),
        messages_scanned: messagesScanned,
        videos_found: videosFound,
        videos_imported: videosImported,
        videos_skipped: videosSkipped,
      });
      await mtprotoClient.disconnect().catch(() => {});
      throw err;
    }
  }

  private async checkDuplicate(channelTelegramId: number, messageId: number): Promise<boolean> {
    const res = await pool.query(
      `SELECT id FROM videos WHERE channel_telegram_id=$1 AND telegram_message_id=$2 AND deleted_at IS NULL LIMIT 1`,
      [channelTelegramId, messageId]
    );
    return res.rows.length > 0;
  }

  private async getVideoIdByMessage(channelTelegramId: number, messageId: number): Promise<string | null> {
    const res = await pool.query(
      `SELECT id FROM videos WHERE channel_telegram_id=$1 AND telegram_message_id=$2 LIMIT 1`,
      [channelTelegramId, messageId]
    );
    return res.rows[0]?.id || null;
  }

  private async insertVideoRecord(channelUuid: string, channelTelegramId: number, msg: NormalizedVideoMessage): Promise<string> {
    const titleRaw = msg.caption?.split('\n')[0] || msg.fileName || `Video #${msg.telegramMessageId}`;
    const title = titleRaw.length > 400 ? titleRaw.substring(0, 400) : titleRaw;
    const slugBase = slugify(title) || `video-${msg.telegramMessageId}`;
    const slug = `${slugBase}-${msg.telegramMessageId}-${Date.now().toString(36)}`;

    const res = await pool.query(
      `INSERT INTO videos
        (title, description, slug, telegram_message_id, channel_id, channel_telegram_id,
         file_size, duration, width, height, mime_type, status, visibility, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'processing','public',$12)
       RETURNING id`,
      [
        title,
        msg.caption || null,
        slug,
        msg.telegramMessageId,
        channelUuid,
        channelTelegramId,
        msg.fileSize,
        msg.duration || null,
        msg.width || null,
        msg.height || null,
        msg.mimeType,
        JSON.stringify({
          file_name: msg.fileName,
          document_id: msg.mediaDocumentId,
          access_hash: msg.mediaAccessHash,
          telegram_date: msg.date,
          raw: msg.raw,
        }),
      ]
    );
    return res.rows[0].id;
  }

  /**
   * Sync single message by ID (useful for webhook/new post)
   */
  async syncSingleMessage(channelTelegramId: number, messageId: number, fileId?: string): Promise<string | null> {
    if (await this.checkDuplicate(channelTelegramId, messageId)) {
      console.log(`Duplicate skip message ${messageId}`);
      return null;
    }
    // If fileId provided via Bot API, use botClient download
    // For simplicity, we insert minimal record and attempt bot download
    if (fileId) {
      try {
        const channelUuid = await this.ensureChannelRow(channelTelegramId);
        const storageKey = `videos/${channelTelegramId}/${messageId}/video.mp4`;
        const { stream, file } = await botClient.downloadByFileId(fileId);
        const savedPath = await this.storage.save(storageKey, stream, 'video/mp4');
        const fileUrl = this.storage.getUrl ? await this.storage.getUrl(storageKey) : savedPath;

        const res = await pool.query(
          `INSERT INTO videos (title, telegram_message_id, channel_id, channel_telegram_id, telegram_file_id, telegram_file_unique_id, file_size, storage_key, storage_url, status, visibility, mime_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ready','public','video/mp4')
           RETURNING id`,
          [
            `Video #${messageId}`,
            messageId,
            channelUuid,
            channelTelegramId,
            file.file_id,
            file.file_unique_id,
            file.file_size || null,
            storageKey,
            fileUrl,
          ]
        );
        return res.rows[0].id;
      } catch (e: any) {
        console.error('Single message bot download failed', e.message);
        throw e;
      }
    }
    // else rely on MTProto fetch single
    const { messages } = await mtprotoClient.fetchChannelHistory(channelTelegramId, { limit: 100, offsetId: messageId + 1 });
    const found = messages.find(m => m.telegramMessageId === messageId);
    if (!found) throw new Error('Message not found in history');
    const channelUuid = await this.ensureChannelRow(channelTelegramId);
    const videoId = await this.insertVideoRecord(channelUuid, channelTelegramId, found);
    return videoId;
  }
}

export const telegramSyncService = new TelegramSyncService();
