
/**
 * Telegram Bot API client
 * IMPORTANT LIMITATION:
 * - Bot API can only get new updates via getUpdates/webhook. It CANNOT fetch historical channel messages.
 * - getChat and getFile work for files the bot has already seen.
 * - For full history sync you MUST use MTProto (mtprotoClient.ts) with api_id/api_hash + user session.
 */
import fetch from 'node-fetch';
import { Readable } from 'stream';
import { env } from '../../config/env';

export interface TelegramChat {
  id: number;
  title: string;
  username?: string;
  type: 'channel' | 'group' | 'supergroup' | 'private';
  description?: string;
  invite_link?: string;
}

export interface TelegramFile {
  file_id: string;
  file_unique_id: string;
  file_size?: number;
  file_path?: string;
}

class BotClient {
  private token: string;
  private baseUrl: string;

  constructor(token?: string) {
    this.token = token || env.TELEGRAM_BOT_TOKEN || '';
    if (!this.token) {
      console.warn('⚠️  TELEGRAM_BOT_TOKEN not set - BotClient will fail on calls');
    }
    this.baseUrl = `https://api.telegram.org/bot${this.token}`;
  }

  private async request<T>(method: string, params?: any): Promise<T> {
    if (!this.token) throw new Error('TELEGRAM_BOT_TOKEN not configured');
    const url = `${this.baseUrl}/${method}`;
    const res = await fetch(url, {
      method: params ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: params ? JSON.stringify(params) : undefined,
    });
    const json: any = await res.json();
    if (!json.ok) {
      throw new Error(`Telegram Bot API error ${method}: ${json.description} (code ${json.error_code})`);
    }
    return json.result as T;
  }

  /**
   * Get chat info (channel). Works for any channel the bot is admin/member of.
   */
  async getChat(chatId: string | number): Promise<TelegramChat> {
    return this.request<TelegramChat>('getChat', { chat_id: chatId });
  }

  /**
   * Get file path from file_id. Returns file_path needed to build download URL.
   * Note: file_id must be known from a previous message update.
   */
  async getFile(fileId: string): Promise<TelegramFile> {
    if (!fileId) throw new Error('fileId required');
    return this.request<TelegramFile>('getFile', { file_id: fileId });
  }

  /**
   * Build direct download URL for a file_path (from getFile)
   */
  getFileUrl(filePath: string): string {
    if (!this.token) throw new Error('Bot token not set');
    if (!filePath) throw new Error('filePath required');
    return `https://api.telegram.org/file/bot${this.token}/${filePath}`;
  }

  /**
   * Download file as Node readable stream from file_path
   */
  async downloadStream(filePath: string): Promise<Readable> {
    const url = this.getFileUrl(filePath);
    const res = await fetch(url);
    if (!res.ok || !res.body) {
      throw new Error(`Failed to download telegram file ${filePath}: ${res.status} ${res.statusText}`);
    }
    // node-fetch v2 body is Node readable
    return res.body as unknown as Readable;
  }

  /**
   * Download file directly by file_id (getFile + stream)
   */
  async downloadByFileId(fileId: string): Promise<{ stream: Readable; file: TelegramFile }> {
    const file = await this.getFile(fileId);
    if (!file.file_path) throw new Error('Telegram did not return file_path');
    const stream = await this.downloadStream(file.file_path);
    return { stream, file };
  }

  /**
   * Bot API can only get new messages via getUpdates - not history.
   * This helper fetches updates (for real-time channel post capture if bot is admin).
   */
  async getUpdates(offset?: number, allowedUpdates?: string[]): Promise<any[]> {
    return this.request<any[]>('getUpdates', {
      offset,
      allowed_updates: allowedUpdates || ['channel_post', 'message'],
      timeout: 0,
    });
  }

  async testConnection(): Promise<{ ok: boolean; botInfo?: any; error?: string }> {
    try {
      const me = await this.request<any>('getMe');
      return { ok: true, botInfo: me };
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }
}

export const botClient = new BotClient();
export { BotClient };
