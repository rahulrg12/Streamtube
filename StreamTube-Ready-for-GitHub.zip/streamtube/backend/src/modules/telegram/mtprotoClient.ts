
/**
 * MTProto client using telegram (gramjs) library.
 * This is the ONLY way to fetch historical channel videos.
 * Bot API cannot fetch history - it only receives new updates.
 *
 * Prerequisites:
 * - API_ID and API_HASH from https://my.telegram.org
 * - SESSION_STRING = StringSession generated via gramjs sign-in (user account, not bot)
 *   WARNING: Never share your user session. Bot tokens cannot be used for MTProto history.
 */
import { TelegramClient } from 'telegram';
import { StringSession } from 'telegram/sessions';
import { Api } from 'telegram/tl';
import { env } from '../../config/env';

export interface NormalizedVideoMessage {
  telegramMessageId: number;
  channelTelegramId: number;
  date: Date;
  caption: string;
  fileName?: string;
  mimeType: string;
  fileSize: number;
  duration?: number;
  width?: number;
  height?: number;
  // MTProto has no bot-style file_id, but we can store access hash refs
  mediaDocumentId?: string; // BigInt as string
  mediaAccessHash?: string;
  thumbFileId?: string;
  messageText?: string;
  raw?: any;
}

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

export class MtProtoClient {
  private client: TelegramClient | null = null;
  private connected = false;

  constructor(
    private apiId?: number,
    private apiHash?: string,
    private sessionString?: string,
  ) {
    this.apiId = apiId || env.TELEGRAM_API_ID;
    this.apiHash = apiHash || env.TELEGRAM_API_HASH;
    this.sessionString = sessionString || env.TELEGRAM_SESSION_STRING;
  }

  async connect(): Promise<TelegramClient> {
    if (this.connected && this.client) return this.client;

    if (!this.apiId || !this.apiHash) {
      throw new Error('TELEGRAM_API_ID and API_HASH required for MTProto history fetch. Get from https://my.telegram.org');
    }
    if (!this.sessionString) {
      throw new Error('TELEGRAM_SESSION_STRING required. Generate via gramjs: new StringSession + client sign-in');
    }

    const stringSession = new StringSession(this.sessionString);
    this.client = new TelegramClient(stringSession, this.apiId, this.apiHash, {
      connectionRetries: 5,
      useWSS: false,
    });

    await this.client.connect();
    this.connected = true;
    console.log('✅ MTProto client connected');
    return this.client;
  }

  async disconnect(): Promise<void> {
    if (this.client) {
      try {
        await this.client.disconnect();
      } catch {}
      this.connected = false;
      console.log('🔌 MTProto disconnected');
    }
  }

  /**
   * Fetch video/document messages from a channel/group.
   * Filters for video/* mime types.
   * Handles FloodWaitError with backoff.
   */
  async fetchChannelHistory(
    channelId: string | number,
    options: {
      limit?: number;
      offsetId?: number;
      minId?: number;
      filterVideoOnly?: boolean;
    } = {}
  ): Promise<{ messages: NormalizedVideoMessage[]; totalScanned: number; hasMore: boolean }> {
    const client = await this.connect();
    const limit = options.limit ?? 100;
    const offsetId = options.offsetId ?? 0;

    // Resolve channel entity
    let entity: any;
    try {
      entity = await client.getEntity(channelId as any);
    } catch (e: any) {
      // Try parsing as -100... id to peer
      throw new Error(`Failed to resolve channel ${channelId}: ${e.message}. Ensure user session is member/admin.`);
    }

    const resultMessages: NormalizedVideoMessage[] = [];
    let totalScanned = 0;
    let lastOffsetId = offsetId;
    let attempts = 0;

    // Use messages.GetHistory
    // For video filtering we can use InputMessagesFilterVideo or Document, then check mime
    while (resultMessages.length < limit) {
      const batchSize = Math.min(100, limit - resultMessages.length);
      try {
        // Prefer filter for document so we can check mime later; but also include video filter.
        // We will fetch without filter and filter manually to avoid missing video/* in document.
        const history: any = await client.invoke(
          new Api.messages.GetHistory({
            peer: entity,
            offsetId: lastOffsetId,
            offsetDate: 0,
            addOffset: 0,
            limit: batchSize,
            maxId: 0,
            minId: options.minId || 0,
            hash: BigInt(0) as any,
          })
        );

        const msgs = (history as any).messages as any[];
        if (!msgs || msgs.length === 0) break;

        totalScanned += msgs.length;

        for (const msg of msgs) {
          if (!(msg instanceof Api.Message)) continue;
          if (!msg.media) continue;

          // Handle MessageMediaDocument
          if (msg.media instanceof Api.MessageMediaDocument) {
            const doc = msg.media.document;
            if (!(doc instanceof Api.Document)) continue;
            const mime = (doc as any).mimeType as string;
            if (!mime) continue;

            // filter video/* or keep if no filter
            if (options.filterVideoOnly !== false) {
              if (!mime.startsWith('video/')) {
                // Some Telegram clients send video as video/mp4 under document
                // Also allow application/octet-stream with video extension? No, strict.
                continue;
              }
            }

            const attrs = (doc as any).attributes || [];
            let duration: number | undefined;
            let width: number | undefined;
            let height: number | undefined;
            let fileName: string | undefined;

            for (const attr of attrs) {
              if (attr instanceof Api.DocumentAttributeVideo) {
                duration = attr.duration;
                width = attr.w;
                height = attr.h;
              } else if (attr instanceof Api.DocumentAttributeFilename) {
                fileName = attr.fileName;
              }
            }

            const normalized: NormalizedVideoMessage = {
              telegramMessageId: msg.id,
              channelTelegramId: typeof channelId === 'string' ? parseInt((channelId as string).replace('-100', ''), 10) : (channelId as number),
              date: new Date((msg.date as number) * 1000),
              caption: (msg.message as string) || '',
              fileName,
              mimeType: mime,
              fileSize: Number((doc as any).size || 0),
              duration,
              width,
              height,
              mediaDocumentId: (doc as any).id?.toString(),
              mediaAccessHash: (doc as any).accessHash?.toString(),
              messageText: msg.message as string,
              raw: {
                id: msg.id,
                mime,
                size: (doc as any).size,
              },
            };
            resultMessages.push(normalized);
          }
        }

        // update offset to lowest id seen
        const ids = msgs.map((m: any) => m.id).filter(Boolean);
        if (ids.length === 0) break;
        lastOffsetId = Math.min(...ids);
        // if we got fewer than batchSize, likely no more history
        if (msgs.length < batchSize) break;

        // polite delay to avoid flood
        await sleep(300);
        attempts = 0;

      } catch (err: any) {
        const msg = err.message || '';
        // Handle FloodWaitError: err.seconds
        if (err.errorMessage === 'FLOOD_WAIT' || msg.includes('FloodWait') || err.seconds) {
          const waitSec = err.seconds || parseInt((msg.match(/(\d+)/) || [])[0] || '30', 10);
          console.warn(`⏳ FloodWait ${waitSec}s, sleeping...`);
          await sleep((waitSec + 2) * 1000);
          continue;
        }
        // CHANNEL_PRIVATE or CHAT_WRITE_FORBIDDEN etc
        if (attempts > 3) throw err;
        attempts++;
        console.warn(`⚠️  fetchChannelHistory error attempt ${attempts}:`, err.message);
        await sleep(1000 * attempts);
      }
    }

    return {
      messages: resultMessages,
      totalScanned,
      hasMore: totalScanned >= limit, // simplistic
    };
  }

  /**
   * Download a document media to a buffer/stream using MTProto.
   * This bypasses Bot API file size limit (20MB). MTProto can fetch up to 2GB (user) or 4GB (premium).
   */
  async downloadMediaToBuffer(messageId: number, entity: any): Promise<Buffer> {
    const client = await this.connect();
    // Get message
    const msgs = await client.getMessages(entity, { ids: [messageId] });
    const msg = msgs[0] as any;
    if (!msg?.media) throw new Error(`No media in message ${messageId}`);
    const buffer = await client.downloadMedia(msg.media, {}) as Buffer;
    return buffer;
  }

  /**
   * Download media as readable stream (using downloadMedia and chunking)
   * gramjs downloadMedia returns Buffer; we wrap in Readable for storageAdapter.
   */
  async downloadMediaStream(message: any): Promise<{ buffer: Buffer; mimeType: string }> {
    const client = await this.connect();
    const buffer = await client.downloadMedia(message.media, {}) as Buffer;
    const mime = (message.media?.document as any)?.mimeType || 'video/mp4';
    return { buffer, mimeType: mime };
  }

  async getChannelInfo(channelId: string | number): Promise<{ title: string; username?: string; participantsCount?: number }> {
    const client = await this.connect();
    const entity = await client.getEntity(channelId as any) as any;
    // get full chat
    try {
      const full = await client.invoke(new Api.channels.GetFullChannel({ channel: entity }));
      const fullChat = (full as any).fullChat as any;
      return {
        title: (entity as any).title || '',
        username: (entity as any).username,
        participantsCount: fullChat?.participantsCount,
      };
    } catch {
      return {
        title: (entity as any).title || '',
        username: (entity as any).username,
      };
    }
  }
}

export const mtprotoClient = new MtProtoClient();
