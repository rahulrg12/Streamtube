
import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';

export interface AppError extends Error {
  statusCode?: number;
  code?: string;
}

export function errorHandler(err: AppError, _req: Request, res: Response, _next: NextFunction) {
  console.error('❌ Error:', err.message, err.stack?.substring(0, 500));

  const status = err.statusCode || 500;
  const response: any = {
    error: err.message || 'Internal server error',
  };

  if (err.code) response.code = err.code;

  if (!env.isProduction && err.stack) {
    response.stack = err.stack.split('\n').slice(0, 5);
  }

  res.status(status).json(response);
}

export function notFoundHandler(_req: Request, res: Response) {
  res.status(404).json({ error: 'Route not found' });
}
