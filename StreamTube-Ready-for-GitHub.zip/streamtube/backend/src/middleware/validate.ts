
import { Request, Response, NextFunction } from 'express';
import { ZodSchema } from 'zod';

export function validate(schema: ZodSchema, source: 'body' | 'query' | 'params' = 'body') {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const data = (req as any)[source];
      const parsed = schema.parse(data);
      (req as any)[source] = parsed;
      next();
    } catch (e: any) {
      if (e.issues) {
        return res.status(400).json({
          error: 'Validation failed',
          details: e.issues.map((i: any) => ({ path: i.path.join('.'), message: i.message })),
        });
      }
      next(e);
    }
  };
}
