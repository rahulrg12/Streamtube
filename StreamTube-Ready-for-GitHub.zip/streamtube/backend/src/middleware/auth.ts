import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { pool } from "../config/database";

export interface AuthRequest extends Request {
  user?: { id: string; email: string; role: string; username: string };
}

export const authGuard = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    let token: string | undefined;

    // Cookie sid
    if (req.cookies?.sid) token = req.cookies.sid;
    // Bearer
    const authHeader = req.headers.authorization;
    if (!token && authHeader?.startsWith("Bearer ")) token = authHeader.substring(7);

    if (!token) {
      return res.status(401).json({ error: "Unauthorized", message: "Missing or invalid token" });
    }

    const secret = process.env.SESSION_SECRET;
    if (!secret) throw new Error("SESSION_SECRET not configured");

    const decoded = jwt.verify(token, secret) as any;
    const result = await pool.query("SELECT id, email, role, username FROM users WHERE id=$1 AND is_active=true", [decoded.id]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: "Unauthorized", message: "User not found" });
    }

    req.user = result.rows[0];
    next();
  } catch (err: any) {
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ error: "Unauthorized", message: "Token expired" });
    }
    return res.status(401).json({ error: "Unauthorized", message: "Invalid token" });
  }
};

export const adminGuard = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.user) return res.status(401).json({ error: "Unauthorized" });
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden", message: "Admin only" });
  }
  next();
};
