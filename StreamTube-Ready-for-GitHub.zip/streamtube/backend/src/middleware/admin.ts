
import { Request, Response, NextFunction } from 'express';
import { pool } from '../config/database';

export async function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const user = (req as any).session?.user || (req as any).user;
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const result = await pool.query(
      `SELECT * FROM admin_users WHERE user_id = $1 AND is_active = true LIMIT 1`,
      [user.id]
    );
    if (result.rows.length === 0) {
      return res.status(403).json({ error: 'Forbidden - admin access required' });
    }
    (req as any).admin = result.rows[0];
    next();
  } catch (e) {
    next(e);
  }
}
