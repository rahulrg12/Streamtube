
import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  DATABASE_URL: z.string().url().or(z.string().startsWith('postgresql://')).min(1, 'DATABASE_URL required'),

  SESSION_SECRET: z.string().min(16, 'SESSION_SECRET must be at least 16 chars'),
  FRONTEND_URL: z.string().url().default('http://localhost:3000'),

  TELEGRAM_BOT_TOKEN: z.string().min(10).optional(),
  TELEGRAM_CHANNEL_ID: z.string().optional(), // e.g. -100123456789
  TELEGRAM_CHANNEL_USERNAME: z.string().optional(), // @channel

  TELEGRAM_API_ID: z.coerce.number().int().positive().optional(),
  TELEGRAM_API_HASH: z.string().optional(),
  TELEGRAM_SESSION_STRING: z.string().optional(),

  STORAGE_TYPE: z.enum(['local', 's3']).default('local'),
  LOCAL_STORAGE_PATH: z.string().default('./uploads'),
  LOCAL_STORAGE_BASE_URL: z.string().url().optional(),

  AWS_S3_BUCKET: z.string().optional(),
  AWS_S3_REGION: z.string().default('us-east-1'),
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_S3_ENDPOINT: z.string().optional(),
  AWS_S3_FORCE_PATH_STYLE: z.coerce.boolean().default(false),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().default(60_000),
  RATE_LIMIT_MAX_REQUESTS: z.coerce.number().default(120),
  STREAM_RATE_LIMIT_MAX: z.coerce.number().default(30),
});

export type Env = z.infer<typeof envSchema> & {
  // helpers
  isProduction: boolean;
  isDevelopment: boolean;
};

function validateEnv(): Env {
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error('❌ Invalid environment variables:', parsed.error.flatten().fieldErrors);
    throw new Error('Invalid environment variables');
  }
  const data = parsed.data as any;

  // Cross-field validation: log warnings for Telegram limits
  if (data.TELEGRAM_BOT_TOKEN && !data.TELEGRAM_API_ID) {
    console.warn(
      '⚠️  TELEGRAM_BOT_TOKEN provided but TELEGRAM_API_ID/API_HASH missing. ' +
      'Bot API CANNOT fetch history. History sync requires MTProto (API_ID, API_HASH, SESSION_STRING).'
    );
  }
  if (data.STORAGE_TYPE === 's3' && !data.AWS_S3_BUCKET) {
    throw new Error('AWS_S3_BUCKET required when STORAGE_TYPE=s3');
  }

  return {
    ...data,
    isProduction: data.NODE_ENV === 'production',
    isDevelopment: data.NODE_ENV === 'development',
  };
}

export const env = validateEnv();
