
import fs from 'fs';
import path from 'path';
import { pool } from '../config/database';
import { env } from '../config/env';

async function ensureMigrationsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id SERIAL PRIMARY KEY,
      filename VARCHAR(255) UNIQUE NOT NULL,
      executed_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);
}

async function getExecutedMigrations(): Promise<Set<string>> {
  const res = await pool.query('SELECT filename FROM schema_migrations ORDER BY id ASC');
  return new Set(res.rows.map((r: any) => r.filename));
}

async function runMigrations() {
  const migrationsDir = path.join(__dirname, 'migrations');
  if (!fs.existsSync(migrationsDir)) {
    console.error(`Migrations dir not found: ${migrationsDir}`);
    process.exit(1);
  }
  const files = fs.readdirSync(migrationsDir)
    .filter(f => f.endsWith('.sql'))
    .sort();

  await ensureMigrationsTable();
  const executed = await getExecutedMigrations();

  console.log(`Found ${files.length} migration files, ${executed.size} already executed`);

  for (const file of files) {
    if (executed.has(file)) {
      console.log(`⏭  Skipping ${file}`);
      continue;
    }
    const fullPath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(fullPath, 'utf8');
    console.log(`🚀 Running ${file}...`);
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
      await client.query('COMMIT');
      console.log(`✅ ${file} completed`);
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error(`❌ Migration ${file} failed:`, err.message);
      throw err;
    } finally {
      client.release();
    }
  }
  console.log('🎉 All migrations applied');
  if (!env.isProduction) {
    await pool.end().catch(() => {});
  }
}

if (require.main === module) {
  runMigrations().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}

export { runMigrations };
