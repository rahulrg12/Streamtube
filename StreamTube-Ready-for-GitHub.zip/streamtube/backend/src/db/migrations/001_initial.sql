
-- StreamTube Initial Schema - 15 tables + indexes
-- Enable pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- 1. users
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(50) UNIQUE NOT NULL,
  email CITEXT UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(100),
  avatar_url TEXT,
  bio TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_created_at ON users(created_at);

-- 2. video_categories
CREATE TABLE IF NOT EXISTS video_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) UNIQUE NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  icon VARCHAR(50),
  parent_id UUID REFERENCES video_categories(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_video_categories_slug ON video_categories(slug);
CREATE INDEX idx_video_categories_parent ON video_categories(parent_id);

-- 3. telegram_channels
CREATE TABLE IF NOT EXISTS telegram_channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id BIGINT UNIQUE NOT NULL, -- Telegram internal ID e.g. -100123456789
  username VARCHAR(100),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  invite_link TEXT,
  avatar_url TEXT,
  subscriber_count INT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  last_synced_at TIMESTAMPTZ,
  last_message_id BIGINT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_telegram_channels_channel_id ON telegram_channels(channel_id);
CREATE INDEX idx_telegram_channels_username ON telegram_channels(username);

-- 4. videos - core
CREATE TABLE IF NOT EXISTS videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(500) NOT NULL,
  description TEXT,
  slug VARCHAR(600) UNIQUE,
  telegram_message_id BIGINT NOT NULL,
  telegram_file_id VARCHAR(500),
  telegram_file_unique_id VARCHAR(255),
  channel_id UUID REFERENCES telegram_channels(id) ON DELETE SET NULL,
  channel_telegram_id BIGINT,
  category_id UUID REFERENCES video_categories(id) ON DELETE SET NULL,
  file_size BIGINT,
  duration INT, -- seconds
  width INT,
  height INT,
  mime_type VARCHAR(100) DEFAULT 'video/mp4',
  thumbnail_url TEXT,
  thumbnail_storage_key VARCHAR(500),
  storage_key VARCHAR(500),
  storage_url TEXT,
  storage_type VARCHAR(20) DEFAULT 'local' CHECK (storage_type IN ('local','s3','telegram')),
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','processing','ready','failed','deleted')),
  visibility VARCHAR(20) DEFAULT 'public' CHECK (visibility IN ('public','unlisted','private')),
  view_count BIGINT DEFAULT 0,
  like_count INT DEFAULT 0,
  dislike_count INT DEFAULT 0,
  comment_count INT DEFAULT 0,
  is_featured BOOLEAN DEFAULT FALSE,
  uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
  metadata JSONB DEFAULT '{}'::jsonb, -- raw telegram metadata, codec info etc
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  CONSTRAINT uq_telegram_msg UNIQUE (channel_telegram_id, telegram_message_id)
);
CREATE INDEX idx_videos_status ON videos(status);
CREATE INDEX idx_videos_visibility ON videos(visibility);
CREATE INDEX idx_videos_channel ON videos(channel_id);
CREATE INDEX idx_videos_category ON videos(category_id);
CREATE INDEX idx_videos_created_at ON videos(created_at DESC);
CREATE INDEX idx_videos_view_count ON videos(view_count DESC);
CREATE INDEX idx_videos_telegram_msg ON videos(telegram_message_id);
CREATE INDEX idx_videos_slug ON videos(slug);
CREATE INDEX idx_videos_search ON videos USING GIN (to_tsvector('english', title || ' ' || COALESCE(description,'')));
CREATE INDEX idx_videos_deleted_at ON videos(deleted_at) WHERE deleted_at IS NULL;

-- 5. telegram_sync_jobs
CREATE TABLE IF NOT EXISTS telegram_sync_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id UUID REFERENCES telegram_channels(id) ON DELETE CASCADE,
  channel_telegram_id BIGINT,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','running','completed','failed','cancelled')),
  job_type VARCHAR(30) DEFAULT 'history_sync' CHECK (job_type IN ('history_sync','new_messages','single_message')),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  messages_scanned INT DEFAULT 0,
  videos_found INT DEFAULT 0,
  videos_imported INT DEFAULT 0,
  videos_skipped INT DEFAULT 0,
  last_offset_id BIGINT DEFAULT 0,
  error_message TEXT,
  logs JSONB DEFAULT '[]'::jsonb,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_sync_jobs_channel ON telegram_sync_jobs(channel_id);
CREATE INDEX idx_sync_jobs_status ON telegram_sync_jobs(status);
CREATE INDEX idx_sync_jobs_created_at ON telegram_sync_jobs(created_at DESC);

-- 6. video_views
CREATE TABLE IF NOT EXISTS video_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  ip_hash VARCHAR(128),
  user_agent TEXT,
  watched_duration INT DEFAULT 0,
  is_unique BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_video_views_video ON video_views(video_id);
CREATE INDEX idx_video_views_user ON video_views(user_id);
CREATE INDEX idx_video_views_created ON video_views(created_at DESC);
CREATE INDEX idx_video_views_video_date ON video_views(video_id, created_at);

-- 7. watch_history
CREATE TABLE IF NOT EXISTS watch_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  progress INT DEFAULT 0, -- seconds watched
  progress_percent NUMERIC(5,2) DEFAULT 0,
  last_watched_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, video_id)
);
CREATE INDEX idx_watch_history_user ON watch_history(user_id, last_watched_at DESC);
CREATE INDEX idx_watch_history_video ON watch_history(video_id);

-- 8. watch_later
CREATE TABLE IF NOT EXISTS watch_later (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, video_id)
);
CREATE INDEX idx_watch_later_user ON watch_later(user_id, added_at DESC);

-- 9. video_likes
CREATE TABLE IF NOT EXISTS video_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  is_like BOOLEAN NOT NULL, -- true=like, false=dislike
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, video_id)
);
CREATE INDEX idx_video_likes_video ON video_likes(video_id);
CREATE INDEX idx_video_likes_user ON video_likes(user_id);
CREATE INDEX idx_video_likes_like ON video_likes(video_id, is_like);

-- 10. comments
CREATE TABLE IF NOT EXISTS comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (char_length(content) >= 1 AND char_length(content) <= 5000),
  parent_id UUID REFERENCES comments(id) ON DELETE CASCADE,
  like_count INT DEFAULT 0,
  is_pinned BOOLEAN DEFAULT FALSE,
  is_edited BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_comments_video ON comments(video_id, created_at DESC);
CREATE INDEX idx_comments_user ON comments(user_id);
CREATE INDEX idx_comments_parent ON comments(parent_id);
CREATE INDEX idx_comments_deleted ON comments(deleted_at) WHERE deleted_at IS NULL;

-- 11. subscriptions (user -> telegram_channel and user -> user)
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES telegram_channels(id) ON DELETE CASCADE,
  subscribed_to_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CHECK (
    (channel_id IS NOT NULL AND subscribed_to_user_id IS NULL) OR
    (channel_id IS NULL AND subscribed_to_user_id IS NOT NULL)
  ),
  UNIQUE(subscriber_id, channel_id),
  UNIQUE(subscriber_id, subscribed_to_user_id)
);
CREATE INDEX idx_subscriptions_subscriber ON subscriptions(subscriber_id);
CREATE INDEX idx_subscriptions_channel ON subscriptions(channel_id);
CREATE INDEX idx_subscriptions_user ON subscriptions(subscribed_to_user_id);

-- 12. playlists
CREATE TABLE IF NOT EXISTS playlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  visibility VARCHAR(20) DEFAULT 'private' CHECK (visibility IN ('public','private','unlisted')),
  thumbnail_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_playlists_user ON playlists(user_id);
CREATE INDEX idx_playlists_visibility ON playlists(visibility);

-- 13. playlist_videos
CREATE TABLE IF NOT EXISTS playlist_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id UUID NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  position INT NOT NULL DEFAULT 0,
  added_by UUID REFERENCES users(id) ON DELETE SET NULL,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(playlist_id, video_id)
);
CREATE INDEX idx_playlist_videos_playlist ON playlist_videos(playlist_id, position ASC);
CREATE INDEX idx_playlist_videos_video ON playlist_videos(video_id);

-- 14. video_reports
CREATE TABLE IF NOT EXISTS video_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  reporter_id UUID REFERENCES users(id) ON DELETE SET NULL,
  reason VARCHAR(50) NOT NULL CHECK (reason IN ('spam','inappropriate','copyright','violence','harassment','other')),
  description TEXT,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','reviewed','resolved','dismissed')),
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_video_reports_video ON video_reports(video_id);
CREATE INDEX idx_video_reports_status ON video_reports(status);
CREATE INDEX idx_video_reports_reporter ON video_reports(reporter_id);

-- 15. admin_users
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(30) NOT NULL DEFAULT 'moderator' CHECK (role IN ('super_admin','moderator','editor')),
  permissions JSONB DEFAULT '{}'::jsonb,
  is_active BOOLEAN DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_admin_users_user ON admin_users(user_id);
CREATE INDEX idx_admin_users_role ON admin_users(role);

-- Sessions table for connect-pg-simple
CREATE TABLE IF NOT EXISTS user_sessions (
  sid VARCHAR NOT NULL PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMPTZ NOT NULL
);
CREATE INDEX idx_user_sessions_expire ON user_sessions(expire);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_users_updated ON users;
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_videos_updated ON videos;
CREATE TRIGGER trg_videos_updated BEFORE UPDATE ON videos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_categories_updated ON video_categories;
CREATE TRIGGER trg_categories_updated BEFORE UPDATE ON video_categories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_channels_updated ON telegram_channels;
CREATE TRIGGER trg_channels_updated BEFORE UPDATE ON telegram_channels FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_watch_history_updated ON watch_history;
CREATE TRIGGER trg_watch_history_updated BEFORE UPDATE ON watch_history FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_comments_updated ON comments;
CREATE TRIGGER trg_comments_updated BEFORE UPDATE ON comments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_playlists_updated ON playlists;
CREATE TRIGGER trg_playlists_updated BEFORE UPDATE ON playlists FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_admin_users_updated ON admin_users;
CREATE TRIGGER trg_admin_users_updated BEFORE UPDATE ON admin_users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
