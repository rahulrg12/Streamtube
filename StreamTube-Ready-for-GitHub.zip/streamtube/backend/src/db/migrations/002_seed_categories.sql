
-- Default categories
INSERT INTO video_categories (name, slug, description, icon) VALUES
  ('Entertainment', 'entertainment', 'Movies, shows and entertainment', 'film'),
  ('Education', 'education', 'Tutorials and educational content', 'book'),
  ('Music', 'music', 'Music videos and performances', 'music'),
  ('Gaming', 'gaming', 'Gaming videos and streams', 'gamepad'),
  ('Tech', 'tech', 'Technology reviews and news', 'cpu'),
  ('Sports', 'sports', 'Sports highlights and analysis', 'trophy'),
  ('News', 'news', 'News and current events', 'newspaper'),
  ('Comedy', 'comedy', 'Funny videos and comedy', 'smile')
ON CONFLICT (slug) DO NOTHING;
