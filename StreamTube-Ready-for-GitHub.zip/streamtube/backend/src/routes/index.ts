
import { Router } from 'express';
import videoRoutes from '../modules/videos/routes';
import authRoutes from '../modules/auth/routes';
import adminRoutes from '../modules/admin/routes';
import { pool } from '../config/database';

const router = Router();

router.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'connected', timestamp: new Date().toISOString() });
  } catch {
    res.status(503).json({ status: 'error', db: 'disconnected' });
  }
});

router.use('/videos', videoRoutes);
router.use('/auth', authRoutes);
router.use('/admin', adminRoutes);

// categories public
router.get('/categories', async (_req, res, next) => {
  try {
    const r = await pool.query(`SELECT id, name, slug, description, icon FROM video_categories ORDER BY name ASC`);
    res.json({ data: r.rows });
  } catch (e) { next(e); }
});

export default router;
