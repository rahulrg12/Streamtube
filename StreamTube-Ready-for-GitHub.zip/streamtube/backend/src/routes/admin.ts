import { Router } from "express";
import { pool } from "../config/database";
import { authGuard, adminGuard } from "../middleware/auth";

const router = Router();

router.get("/stats", authGuard, adminGuard, async (req, res, next) => {
  try {
    const totalVideos = await pool.query("SELECT COUNT(*) FROM videos WHERE status='ready'");
    const totalSize = await pool.query("SELECT COALESCE(SUM(file_size),0) as sum FROM videos");
    const totalViews = await pool.query("SELECT COALESCE(SUM(views),0) as sum FROM videos");
    const channels = await pool.query("SELECT COUNT(*) FROM telegram_channels");
    const recentSyncs = await pool.query("SELECT * FROM sync_logs ORDER BY started_at DESC LIMIT 5");

    res.json({
      total_videos: parseInt(totalVideos.rows[0].count, 10),
      total_size_bytes: Number(totalSize.rows[0].sum),
      total_views: parseInt(totalViews.rows[0].sum, 10),
      channels: parseInt(channels.rows[0].count, 10),
      storage_type: process.env.STORAGE_TYPE || "telegram",
      recent_syncs: recentSyncs.rows,
      telegram_limits: {
        bot_api_max_file_size: "2GB (4GB with local API)",
        historical_sync_supported: false,
        historical_sync_via: "MTProto only",
        bot_api_can_get_history: false,
        message: "Bot API cannot fetch history, only new messages. History needs MTProto with api_id/hash + user session. See docs/TELEGRAM.md"
      }
    });
  } catch (e) { next(e); }
});

export default router;
