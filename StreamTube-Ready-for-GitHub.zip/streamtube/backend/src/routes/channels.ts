import { Router } from "express";
import { pool } from "../config/database";
import { authGuard, adminGuard } from "../middleware/auth";

const router = Router();

router.get("/", authGuard, adminGuard, async (req, res, next) => {
  try {
    const result = await pool.query("SELECT tc.*, (SELECT COUNT(*) FROM videos WHERE channel_id=tc.id) as video_count FROM telegram_channels tc ORDER BY created_at DESC");
    res.json({ channels: result.rows });
  } catch (e) { next(e); }
});

router.post("/sync/history", authGuard, adminGuard, async (req, res, next) => {
  try {
    const { telegram_channel_id, limit = 100, offset_id = 0 } = req.body;

    if (!process.env.API_ID || !process.env.API_HASH || !process.env.SESSION_STRING) {
      return res.status(400).json({
        error: "MTProto not configured",
        message: "API_ID, API_HASH, SESSION_STRING required for historical sync. Bot API cannot fetch history.",
        hint: "See docs/TELEGRAM.md and run backend/scripts/generate-session.ts"
      });
    }

    // Real implementation would use GramJS TelegramClient.iterMessages
    // For docs/prod template we return 202 with job id, and implement actual logic in service file
    // Here we simulate: if limit <= 100 return 200 with counts, else 202 async

    // In real code:
    /*
    const client = new TelegramClient(new StringSession(SESSION_STRING), API_ID, API_HASH, {});
    await client.connect();
    const channel = await client.getEntity(telegram_channel_id);
    let scanned=0, imported=0;
    for await (const msg of client.iterMessages(channel, {limit, offsetId: offset_id})) {
      scanned++;
      if (msg.media?.document) { imported++; save to DB }
    }
    */

    if (limit > 1000) {
      return res.status(400).json({ error: "Limit too high", message: "Max 1000 per request, use offset_id pagination" });
    }

    // Simulate success response for testing/deploy docs
    res.json({
      scanned: limit,
      imported: Math.floor(limit * 0.2),
      flood_wait_seconds: 0,
      message: "Historical sync via MTProto completed (simulated in this template, replace with real GramJS call in production)",
      warning: "Bot API alone cannot fetch history - this endpoint requires MTProto"
    });
  } catch (e: any) {
    if (e.errorMessage?.includes("FLOOD") || e.message?.includes("FloodWait")) {
      const seconds = e.seconds || 30;
      return res.status(429).json({ error: "FloodWait", retry_after: seconds, message: `Telegram rate limit - retry after ${seconds}s` });
    }
    next(e);
  }
});

export default router;
