import { Router } from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { pool } from "../config/database";
import { authGuard, AuthRequest } from "../middleware/auth";

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  username: z.string().min(2).max(50),
});

router.post("/register", async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "ValidationError", details: parsed.error.errors });
    const { email, password, username } = parsed.data;

    const exists = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
    if (exists.rows.length > 0) return res.status(409).json({ error: "Conflict", message: "Email exists" });

    const hash = await bcrypt.hash(password, 10);
    const adminCheck = await pool.query("SELECT id FROM users WHERE role='admin' LIMIT 1");
    const role = adminCheck.rows.length === 0 ? "admin" : "user";

    const result = await pool.query(
      "INSERT INTO users (email, username, password_hash, role) VALUES ($1,$2,$3,$4) RETURNING id, email, username, role, created_at",
      [email, username, hash, role]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) { next(e); }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "ValidationError", message: "email and password required" });

    const result = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
    if (result.rows.length === 0) return res.status(401).json({ error: "Unauthorized", message: "Invalid credentials" });

    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Unauthorized", message: "Invalid credentials" });

    const secret = process.env.SESSION_SECRET!;
    const token = jwt.sign({ id: user.id, role: user.role }, secret, { expiresIn: "7d" });
    const tokenHash = require("crypto").createHash("sha256").update(token).digest("hex");

    await pool.query(
      "INSERT INTO sessions (user_id, token_hash, expires_at, user_agent, ip_address) VALUES ($1,$2,NOW()+INTERVAL '7 days',$3,$4)",
      [user.id, tokenHash, req.headers["user-agent"], req.ip]
    );

    const secure = process.env.NODE_ENV === "production";
    res.cookie("sid", token, {
      httpOnly: true,
      secure,
      sameSite: (process.env.COOKIE_SAMESITE as any) || "lax",
      domain: process.env.COOKIE_DOMAIN || undefined,
      maxAge: 7*24*60*60*1000,
      path: "/",
    });

    res.json({ token, user: { id: user.id, email: user.email, username: user.username, role: user.role } });
  } catch (e) { next(e); }
});

router.post("/logout", authGuard, async (req: AuthRequest, res, next) => {
  try {
    const token = req.cookies?.sid || req.headers.authorization?.replace("Bearer ", "");
    if (token) {
      const hash = require("crypto").createHash("sha256").update(token).digest("hex");
      await pool.query("DELETE FROM sessions WHERE token_hash=$1", [hash]);
    }
    res.clearCookie("sid");
    res.json({ message: "Logged out" });
  } catch (e) { next(e); }
});

router.get("/me", authGuard, async (req: AuthRequest, res) => {
  res.json(req.user);
});

export default router;
