import app from "./app";
import { pool } from "./config/database";

const PORT = process.env.PORT || 4000;

async function start() {
  try {
    await pool.query("SELECT 1");
    console.log("✅ Database connected");
  } catch (e) {
    console.error("❌ Database connection failed", e);
    process.exit(1);
  }

  if (!process.env.TELEGRAM_BOT_TOKEN) console.warn("⚠️ TELEGRAM_BOT_TOKEN not set - Bot sync disabled");
  if (!process.env.SESSION_STRING) console.warn("⚠️ SESSION_STRING not set - MTProto history sync disabled (honest: history via Bot API NOT supported)");

  app.listen(PORT, () => {
    console.log(`🚀 StreamTube backend running on http://localhost:${PORT}`);
    console.log(`   Storage: ${process.env.STORAGE_TYPE || "telegram"}`);
    console.log(`   Env: ${process.env.NODE_ENV || "development"}`);
  });
}

start();
