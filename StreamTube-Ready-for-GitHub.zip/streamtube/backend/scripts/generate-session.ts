import { TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions";
import { Api } from "telegram";
import * as dotenv from "dotenv";
import * as fs from "fs";
import * as path from "path";
import readline from "readline";

dotenv.config({ path: path.join(__dirname, "../.env") });
dotenv.config(); // also root .env

const apiId = Number(process.env.API_ID);
const apiHash = process.env.API_HASH as string;

if (!apiId || !apiHash) {
  console.error("Missing API_ID or API_HASH in env. Get from https://my.telegram.org -> API development tools");
  process.exit(1);
}

function question(query: string): Promise<string> {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(query, (ans) => { rl.close(); resolve(ans); }));
}

async function main() {
  console.log("=== StreamTube MTProto Session Generator ===");
  console.log("API_ID:", apiId);
  console.log("API_HASH:", apiHash.slice(0, 6) + "...");
  console.log("\nThis will log in as YOUR user account to generate SESSION_STRING.");
  console.log("SESSION_STRING is equivalent to your password - keep secret, never commit.\n");

  const stringSession = new StringSession(process.env.SESSION_STRING || "");

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  await client.start({
    phoneNumber: async () => await question("Phone number with country code (e.g. +1234567890): "),
    password: async () => await question("2FA password (if enabled, else leave empty): "),
    phoneCode: async () => await question("Code you received in Telegram (e.g. 12345): "),
    onError: (err) => console.error("Login error:", err),
  });

  console.log("\n✅ Connected as user!");

  const me = await client.getMe();
  console.log("Logged in as:", (me as any).firstName, `@${(me as any).username || 'no username'}`, `id=${(me as any).id}`);

  const sessionString = client.session.save() as unknown as string;
  console.log("\n=== SESSION_STRING GENERATED ===");
  console.log(sessionString);
  console.log("=== END SESSION_STRING ===\n");

  console.log("Save to your .env:");
  console.log(`SESSION_STRING=${sessionString}`);
  console.log("\nSecurity: This string allows full access to your account. Store as secret env var, never commit to git.");
  console.log("You can revoke via Telegram app: Settings -> Privacy -> Active Sessions -> Terminate.");

  // Optionally test channel access
  const testChannelId = await question("\nOptional test: Enter TELEGRAM_CHANNEL_ID (-100...) to test access (or leave empty to skip): ");
  if (testChannelId) {
    try {
      const entity = await client.getEntity(Number(testChannelId) || testChannelId);
      console.log("✅ Channel entity resolved:", entity);
      // Try to get 1 message history
      const history = await client.invoke(new Api.messages.GetHistory({
        peer: entity as any,
        offsetId: 0,
        limit: 1,
        offsetDate: 0,
        addOffset: 0,
        maxId: 0,
        minId: 0,
        hash: BigInt(0),
      }));
      console.log("✅ Can read history, messages count:", (history as any).messages?.length || 0);
    } catch (e: any) {
      console.error("❌ Channel access error:", e.message);
      console.error("Ensure your user account is member of that channel.");
    }
  }

  await client.disconnect();
  console.log("\nDone. Disconnecting...");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
