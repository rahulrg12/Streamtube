-- StreamTube consolidated schema
-- PostgreSQL 14+
-- Honest: Bot API cannot fetch history, need MTProto for historical sync.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Users
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(100) NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Sessions
CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    user_agent TEXT,
    ip_address INET,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);

-- Telegram channels
CREATE TABLE IF NOT EXISTS telegram_channels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    telegram_channel_id BIGINT NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    username VARCHAR(255),
    invite_link TEXT,
    description TEXT,
    added_by UUID REFERENCES users(id) ON DELETE SET NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_telegram_channels_tg_id ON telegram_channels(telegram_channel_id);

-- Videos core
CREATE TABLE IF NOT EXISTS videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    telegram_message_id BIGINT NOT NULL,
    telegram_file_id TEXT NOT NULL,
    telegram_file_unique_id TEXT NOT NULL,
    telegram_channel_id BIGINT NOT NULL,
    channel_id UUID REFERENCES telegram_channels(id) ON DELETE SET NULL,
    file_name TEXT NOT NULL,
    mime_type VARCHAR(100) NOT NULL DEFAULT 'video/mp4',
    file_size BIGINT NOT NULL CHECK (file_size > 0),
    duration INTEGER,
    width INTEGER,
    height INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_file_id TEXT,
    thumbnail_url TEXT,
    storage_type VARCHAR(20) NOT NULL DEFAULT 'telegram' CHECK (storage_type IN ('telegram','s3','local')),
    s3_key TEXT,
    local_path TEXT,
    is_public BOOLEAN NOT NULL DEFAULT true,
    status VARCHAR(20) NOT NULL DEFAULT 'ready' CHECK (status IN ('pending','processing','ready','failed','deleted')),
    views INTEGER NOT NULL DEFAULT 0,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(channel_id, telegram_message_id),
    UNIQUE(telegram_file_unique_id, channel_id)
);
CREATE INDEX IF NOT EXISTS idx_videos_channel_id ON videos(channel_id);
CREATE INDEX IF NOT EXISTS idx_videos_telegram_channel_id ON videos(telegram_channel_id);
CREATE INDEX IF NOT EXISTS idx_videos_telegram_message_id ON videos(telegram_message_id);
CREATE INDEX IF NOT EXISTS idx_videos_file_id ON videos(telegram_file_id);
CREATE INDEX IF NOT EXISTS idx_videos_unique_id ON videos(telegram_file_unique_id);
CREATE INDEX IF NOT EXISTS idx_videos_created_at ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_title_trgm ON videos USING gin (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_videos_is_public ON videos(is_public) WHERE is_public = true;
CREATE INDEX IF NOT EXISTS idx_videos_status ON videos(status);
CREATE INDEX IF NOT EXISTS idx_videos_views ON videos(views DESC);
CREATE INDEX IF NOT EXISTS idx_videos_search ON videos(is_public, created_at DESC) WHERE status='ready';

-- Video tags
CREATE TABLE IF NOT EXISTS video_tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    tag VARCHAR(50) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(video_id, tag)
);
CREATE INDEX IF NOT EXISTS idx_video_tags_video_id ON video_tags(video_id);
CREATE INDEX IF NOT EXISTS idx_video_tags_tag ON video_tags(tag);

-- Sync logs
CREATE TABLE IF NOT EXISTS sync_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    channel_id UUID REFERENCES telegram_channels(id) ON DELETE SET NULL,
    telegram_channel_id BIGINT NOT NULL,
    sync_type VARCHAR(30) NOT NULL CHECK (sync_type IN ('bot_update','mtproto_history','upload','manual')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    messages_scanned INTEGER NOT NULL DEFAULT 0,
    videos_found INTEGER NOT NULL DEFAULT 0,
    videos_imported INTEGER NOT NULL DEFAULT 0,
    errors JSONB DEFAULT '[]'::jsonb,
    triggered_by UUID REFERENCES users(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'running' CHECK (status IN ('running','completed','failed','rate_limited')),
    flood_wait_seconds INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sync_logs_channel_id ON sync_logs(channel_id);
CREATE INDEX IF NOT EXISTS idx_sync_logs_started_at ON sync_logs(started_at DESC);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_users_updated_at ON users;
CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_channels_updated_at ON telegram_channels;
CREATE TRIGGER trg_channels_updated_at BEFORE UPDATE ON telegram_channels FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS trg_videos_updated_at ON videos;
CREATE TRIGGER trg_videos_updated_at BEFORE UPDATE ON videos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- View public videos
CREATE OR REPLACE VIEW public_videos AS
SELECT 
  v.id, v.title, v.description, v.file_name, v.mime_type, v.file_size, v.duration, v.width, v.height, v.views, v.thumbnail_url, v.created_at, v.telegram_channel_id,
  tc.title AS channel_title, tc.username AS channel_username
FROM videos v
LEFT JOIN telegram_channels tc ON v.channel_id = tc.id
WHERE v.is_public = true AND v.status = 'ready';
