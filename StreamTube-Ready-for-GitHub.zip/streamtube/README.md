# StreamTube - Telegram Storage Streaming

YouTube-like video streaming platform using Telegram as storage backend. Honest about Telegram API limitations.

## Summary

StreamTube lets you create a video library where actual video files live in a Telegram channel (private or public), while metadata, auth, views live in Postgres, and streaming is proxied via backend with Range support. Optional S3/R2 for production performance.

### Honest Limits (Read First)

**Historical sync via Bot API alone NOT supported.**

- **Bot API CANNOT fetch channel history.** There is no `getChatHistory` method for bots. `getUpdates` only returns NEW messages after bot became admin and while polling. If your channel already has 1000 videos, Bot API will never see them.
- **You MUST use MTProto (user account) for history:** Requires `API_ID`, `API_HASH` from my.telegram.org + `SESSION_STRING` generated from user phone login. Only MTProto can call `messages.getHistory`.
- **File size:** Bot API official server 2GB max (4GB with self-hosted local Bot API server). Exceed -> 400 file too big.
- **Streaming via Telegram proxy** does NOT support HTTP Range natively. Backend fakes Range by downloading and slicing, slow seeking, high memory. For prod use `STORAGE_TYPE=s3`.
- **Rate limits:** Bot API 429 slow, MTProto FloodWait can be seconds to hours if you scrape too fast.

We document these everywhere because many tutorials lie.

## Tech Stack

- **Backend:** Node.js 20 + TypeScript + Express + Postgres (pg) + `node-telegram-bot-api` + `telegram` (GramJS MTProto) + S3 SDK
- **Frontend:** React 18 + Vite + React Router + Zustand + Axios
- **Infra:** Docker Compose (postgres + backend + frontend), Render/Railway/DO for backend, Vercel for frontend, S3/R2/DO Spaces optional, CDN Cloudflare
- **Auth:** JWT + httpOnly secure cookies (SameSite Lax, Secure in prod)
- **Testing:** Vitest + Supertest

## Architecture Diagram (text)

```
[User Browser]
     |
     +--(HTTPS)--> [CDN Cloudflare] --> [Frontend Vercel: React SPA]
     |                                  |  |
     |                                  |  +--> GET /api/videos (list)
     |                                  |  +--> GET /api/videos/:id/stream (Range -> video tag)
     |                                  |
     +--(HTTPS)--> [Backend API Render/Railway]
                    |   |   |
                    |   |   +--> [Postgres] users, videos, channels, sync_logs
                    |   |   |
                    |   |   +--> [Telegram Bot API] via BOT_TOKEN
                    |   |   |      - getUpdates / webhook for NEW channel_post
                    |   |   |      - getFile + /file/botTOKEN/file_path download
                    |   |   |      - sendVideo for uploads (2GB limit)
                    |   |   |
                    |   |   +--> [Telegram MTProto] via API_ID/HASH/SESSION_STRING
                    |   |          - messages.getHistory for OLD videos (required)
                    |   |          - Handles FloodWait
                    |   |
                    |   +--> [Storage Adapter]
                    |          - telegram: proxy from Bot API (dev, slow seek)
                    |          - s3: redirect/presigned proxy to S3 (prod, fast Range)
                    |          - local: fs.createReadStream (single VPS)
                    |
                    +--> [S3/R2/DO Spaces] (optional, prod)
                            +--> [CDN] CloudFront / Cloudflare for videos + thumbs

Telegram Channel (private) <-- Bot is admin, posts videos --> Bot API + MTProto read
```

Flow:
1. Admin creates channel, adds bot as admin, gets numeric CHANNEL_ID -100...
2. First time: Admin generates MTProto session via script `backend/scripts/generate-session.ts`
3. Calls POST /api/channels/sync/history (MTProto) -> iterates history, extracts video/documents, saves to DB videos table with file_id/file_unique_id.
4. After that, new videos posted to channel trigger bot webhook/getUpdates -> POST /api/videos/sync saves them.
5. User browses frontend GET /api/videos list, clicks video -> <video src="/api/videos/:id/stream"> browser sends Range, backend proxies from storage adapter with 206 Partial Content.
6. Optional upload POST /api/videos/upload admin uploads local file -> send to Telegram channel + S3.

## Features

- Auth (register/login/logout/me) with role admin/user, first user admin
- Video CRUD, search, pagination, views tracking
- Streaming with HTTP Range 206 support
- Download endpoint attachment
- Channel management, Bot sync for new, MTProto sync for history (honest split)
- Admin stats total size, FloodWait handling
- Storage adapters pluggable
- Secure cookies, CORS, Helmet, rate limiting

## 16 API Endpoints (see docs/API.md full)

1. POST /api/auth/register
2. POST /api/auth/login
3. POST /api/auth/logout
4. GET /api/auth/me
5. GET /api/videos (list, search)
6. GET /api/videos/:id
7. GET /api/videos/:id/stream (Range)
8. GET /api/videos/:id/download
9. POST /api/videos/sync (Bot new only)
10. POST /api/videos/upload (Admin multipart)
11. DELETE /api/videos/:id (Admin)
12. PATCH /api/videos/:id (Admin)
13. GET /api/channels (Admin)
14. POST /api/channels/sync/history (MTProto Admin, historical)
15. GET /api/admin/stats (Admin)
16. GET /api/health (public)

All documented with examples curl + JSON.

## Project Structure

```
streamtube/
├── docs/
│   ├── API.md (all 16 endpoints with examples)
│   ├── SETUP.md (local install Postgres, bot, channel, MTProto session script)
│   ├── DEPLOYMENT.md (Vercel+Render/Railway/DO, env vars HTTPS secure cookies CDN)
│   ├── TELEGRAM.md (REAL limitations: Bot cannot get history, getFile, 2GB/4GB, MTProto how to get api_id/hash, session script, FloodWait, streaming proxy vs storage adapter, fallback)
│   └── TROUBLESHOOTING.md
├── database/
│   └── schema.sql (consolidated all tables indexes FKs)
├── backend/
│   ├── src/
│   │   ├── tests/api.test.ts (supertest videos list, stream Range, auth guard, admin guard)
│   │   ├── routes/ (auth, videos, channels, admin)
│   │   ├── middleware/ (auth, admin, error)
│   │   ├── config/ (env validation)
│   │   └── index.ts
│   ├── scripts/
│   │   └── generate-session.ts (MTProto session generator node script)
│   ├── Dockerfile
│   └── package.json (real deps: express, pg, node-telegram-bot-api, telegram, etc)
├── frontend/
│   ├── src/
│   ├── Dockerfile + nginx.conf
│   └── package.json
├── docker-compose.yml (postgres backend frontend volumes)
├── .env.example (all credentials explained)
├── .gitignore
└── README.md (this)
```

## Credentials Explained

See .env.example + docs.

- TELEGRAM_BOT_TOKEN: from @BotFather /newbot, secret, used for Bot API new updates, getFile, sendVideo
- TELEGRAM_CHANNEL_ID: numeric -100..., from forwarding to @userinfobot, bot must be admin, target channel
- API_ID: integer from https://my.telegram.org -> API development tools -> Create app, not secret but app-specific
- API_HASH: hex string from same page, secret
- SESSION_STRING: long base64 from backend/scripts/generate-session.ts, StringSession, equivalent to your Telegram password, highest secret, allows login as you, revoke via Telegram Settings -> Active sessions
- DATABASE_URL: Postgres connection, e.g. postgres://user:pass@host:5432/db?sslmode=require prod, secret
- SESSION_SECRET: random 32-64 chars, e.g. openssl rand -base64 32, for JWT + cookie signing, secret, rotation invalidates all sessions
- STORAGE_TYPE: telegram|s3|local, not secret, telegram default dev slow, s3 prod fast Range
- S3_*: S3_ENDPOINT, S3_REGION, S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_PUBLIC_URL, CDN_URL, only if STORAGE_TYPE=s3, keys secret

All secrets never commit, .gitignore includes .env *.session.

## Quick Start Local (full in docs/SETUP.md)

```bash
git clone ... && cd streamtube
npm install
docker-compose up -d postgres
psql $DATABASE_URL -f database/schema.sql
# Create bot @BotFather, channel, add bot admin, get -100 ID
# Get API_ID/HASH from my.telegram.org
# Generate session
cd backend && npm install && npm run telegram:session
# Fill backend/.env from .env.example
npm run dev # backend :4000
# frontend
cd frontend && npm install && npm run dev # :5173
# First user admin
curl -X POST http://localhost:4000/api/auth/register -d '{"email":"admin@ex.com","password":"Pass123!","username":"admin"}' -H "Content-Type: application/json"
```

## Deployment (full docs/DEPLOYMENT.md)

- Frontend Vercel: root frontend, framework Vite, env VITE_API_URL https://api...
- Backend Render/Railway/DO: root backend, build npm install && npm run build, start npm start, env vars all secrets, add Managed Postgres
- Env: NODE_ENV production, COOKIE_SECURE true, FRONTEND_URL exact domain CORS, SESSION_SECRET random
- Storage: S3 recommended prod for Range fast seeking
- HTTPS secure cookies, HSTS via Helmet
- CDN Cloudflare in front of API and S3

## Testing

```bash
cd backend
npm test # vitest + supertest
# tests in src/tests/api.test.ts covers:
# - GET /api/videos list returns pagination
# - GET /api/videos/:id/stream Range header 206 + Content-Range
# - Auth guard 401 without token, Admin guard 403 non-admin delete
```

## Database Schema (see database/schema.sql)

Tables: users, sessions, telegram_channels, videos, video_tags, sync_logs, view public_videos. All with indexes, FKs, unique constraints, trgm search.

## Honest Comparison: What works and what doesn't

- ✅ New videos after bot admin: Works via Bot API
- ❌ Old videos: Bot API alone NEVER works, need MTProto history sync
- ✅ Streaming: Works but prod needs S3 for good seeking
- ✅ Upload 2GB: Bot API limit, 4GB with local API server
- ✅ S3 fallback works

## License MIT

## Disclaimer

Uses Telegram as storage is against Telegram ToS if you abuse? For personal/educational use. Session string is your account, don't share. This project is not affiliated with Telegram.

State clearly: historical sync via Bot API alone NOT supported. Use MTProto.
