/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: "#ff0000",
        dark: {
          50: "#f8f8f8",
          100: "#f1f1f1",
          200: "#e5e7eb",
          800: "#212121",
          900: "#0f0f0f",
          950: "#030303",
        }
      },
      fontFamily: {
        sans: ['Roboto', 'Inter', 'system-ui', 'sans-serif']
      }
    },
  },
  plugins: [],
}
