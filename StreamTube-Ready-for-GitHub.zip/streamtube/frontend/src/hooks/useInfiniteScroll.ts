import { useEffect, useRef, useCallback, useState } from 'react';

interface Options {
  enabled?: boolean;
  rootMargin?: string;
  threshold?: number;
}

export function useInfiniteScroll(
  onIntersect: () => void,
  options: Options = {}
) {
  const { enabled = true, rootMargin = '400px', threshold = 0 } = options;
  const observerRef = useRef<IntersectionObserver | null>(null);
  const targetRef = useRef<HTMLDivElement | null>(null);

  const setTarget = useCallback((node: HTMLDivElement | null) => {
    targetRef.current = node;
  }, []);

  useEffect(() => {
    if (!enabled) return;
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          onIntersect();
        }
      },
      { rootMargin, threshold }
    );

    if (targetRef.current) observerRef.current.observe(targetRef.current);

    return () => {
      if (observerRef.current) observerRef.current.disconnect();
    };
  }, [enabled, onIntersect, rootMargin, threshold]);

  // Re-observe when target changes via effect
  useEffect(() => {
    if (!enabled) return;
    const obs = observerRef.current;
    const el = targetRef.current;
    if (obs && el) obs.observe(el);
  });

  return { ref: setTarget };
}

export function useIntersectionObserver(
  callback: () => void,
  deps: any[] = []
) {
  const [element, setElement] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (!element) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) callback();
      },
      { rootMargin: '600px' }
    );
    observer.observe(element);
    return () => observer.disconnect();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [element, ...deps]);

  return setElement;
}
