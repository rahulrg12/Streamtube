export interface User {
  _id: string;
  username: string;
  email: string;
  avatar?: string;
  channelName?: string;
  subscribersCount?: number;
  isSubscribed?: boolean;
  role?: 'user' | 'admin';
  createdAt?: string;
}

export interface Video {
  _id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl?: string;
  hlsUrl?: string;
  duration: number;
  views: number;
  likes: number;
  dislikes: number;
  channel: User | { _id: string; username: string; avatar?: string; channelName?: string };
  category: string;
  tags?: string[];
  createdAt: string;
  isLiked?: boolean;
  isDisliked?: boolean;
  isInWatchLater?: boolean;
}

export interface Comment {
  _id: string;
  text: string;
  user: User;
  video: string;
  likes?: number;
  createdAt: string;
  updatedAt?: string;
  isEdited?: boolean;
  isOwn?: boolean;
}

export interface PaginatedResponse<T> {
  videos?: T[];
  data?: T[];
  total?: number;
  page: number;
  limit: number;
  hasMore: boolean;
  totalPages?: number;
}

export interface TelegramConfig {
  botToken?: string;
  channelId?: string;
  apiId?: string;
  apiHash?: string;
  sessionString?: string;
  isConnected?: boolean;
  lastSync?: string;
  mode: 'bot' | 'mtproto';
}

export interface SyncLog {
  _id: string;
  type: 'history' | 'new' | 'test';
  status: 'success' | 'failed' | 'running';
  message: string;
  count?: number;
  createdAt: string;
}

export type SortOption = 'newest' | 'popular' | 'oldest';
export const CATEGORIES = [
  'All',
  'Music',
  'Gaming',
  'News',
  'Sports',
  'Learning',
  'Fashion',
  'Podcasts',
  'Comedy',
  'Movies',
  'Live',
  'Technology',
] as const;
