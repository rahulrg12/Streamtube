import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export const api = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      const path = window.location.pathname;
      if (!['/login', '/register'].includes(path)) {
        localStorage.removeItem('streamtube-user');
      }
    }
    return Promise.reject(error);
  }
);

// Auth
export const authApi = {
  login: (data: { email: string; password: string }) =>
    api.post('/api/auth/login', data),
  register: (data: { username: string; email: string; password: string }) =>
    api.post('/api/auth/register', data),
  me: () => api.get('/api/auth/me'),
  logout: () => api.post('/api/auth/logout'),
};

// Videos
export const videoApi = {
  getAll: (params: {
    page?: number;
    limit?: number;
    category?: string;
    sort?: string;
    search?: string;
  }) => api.get('/api/videos', { params }),
  getById: (id: string) => api.get(`/api/videos/${id}`),
  getRelated: (id: string) => api.get(`/api/videos/${id}/related`),
  incrementView: (id: string) => api.post(`/api/videos/${id}/views`),
  like: (id: string) => api.post(`/api/videos/${id}/like`),
  dislike: (id: string) => api.post(`/api/videos/${id}/dislike`),
  delete: (id: string) => api.delete(`/api/videos/${id}`),
  search: (q: string, params?: any) =>
    api.get('/api/videos/search', { params: { q, ...params } }),
  getStreamUrl: (id: string) => `${API_URL}/api/videos/${id}/stream`,
  getHlsUrl: (id: string) => `${API_URL}/api/videos/${id}/hls/index.m3u8`,
};

// Comments
export const commentApi = {
  getByVideo: (videoId: string, params?: { page?: number; limit?: number }) =>
    api.get(`/api/videos/${videoId}/comments`, { params }),
  create: (videoId: string, text: string) =>
    api.post(`/api/videos/${videoId}/comments`, { text }),
  update: (id: string, text: string) => api.put(`/api/comments/${id}`, { text }),
  delete: (id: string) => api.delete(`/api/comments/${id}`),
};

// User interactions
export const userApi = {
  getHistory: (params?: { page?: number }) => api.get('/api/history', { params }),
  addToHistory: (videoId: string) => api.post('/api/history', { videoId }),
  clearHistory: () => api.delete('/api/history'),
  removeFromHistory: (videoId: string) => api.delete(`/api/history/${videoId}`),
  getWatchLater: () => api.get('/api/watch-later'),
  addToWatchLater: (videoId: string) => api.post('/api/watch-later', { videoId }),
  removeFromWatchLater: (videoId: string) => api.delete(`/api/watch-later/${videoId}`),
  subscribe: (channelId: string) => api.post(`/api/users/${channelId}/subscribe`),
  unsubscribe: (channelId: string) => api.delete(`/api/users/${channelId}/subscribe`),
};

// Admin / Telegram
export const adminApi = {
  getTelegramConfig: () => api.get('/api/admin/telegram/config'),
  saveTelegramConfig: (data: any) => api.post('/api/admin/telegram/config', data),
  testConnection: () => api.post('/api/admin/telegram/test'),
  syncHistory: () => api.post('/api/admin/telegram/sync/history'),
  syncNew: () => api.post('/api/admin/telegram/sync/new'),
  getLogs: () => api.get('/api/admin/logs'),
  getAllVideos: (params?: any) => api.get('/api/admin/videos', { params }),
};
