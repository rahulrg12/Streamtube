import { useState } from 'react';
import type { Video } from '../types';
import { videoApi, userApi } from '../services/api';
import { useAuthStore } from '../stores/useAuthStore';

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n/1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n/1_000).toFixed(1)}K`;
  return String(n);
}

export default function VideoInfo({ video, onUpdate }: { video: Video; onUpdate?: (v: Video) => void }) {
  const { isAuthenticated } = useAuthStore();
  const [local, setLocal] = useState(video);
  const [showDesc, setShowDesc] = useState(false);
  const [copied, setCopied] = useState(false);
  const [subLoading, setSubLoading] = useState(false);

  const update = (patch: Partial<Video>) => {
    const nv = { ...local, ...patch };
    setLocal(nv);
    onUpdate?.(nv);
  };

  const handleLike = async () => {
    if (!isAuthenticated) { window.location.href = '/login'; return; }
    const wasLiked = local.isLiked;
    update({
      isLiked: !wasLiked,
      isDisliked: false,
      likes: wasLiked ? local.likes - 1 : local.likes + (local.isDisliked ? 1 : 1) + (local.isDisliked ? 0 : 0),
      dislikes: local.isDisliked ? local.dislikes - 1 : local.dislikes,
    });
    try {
      await videoApi.like(local._id);
    } catch {
      update(video);
    }
  };

  const handleDislike = async () => {
    if (!isAuthenticated) { window.location.href = '/login'; return; }
    const wasDisliked = local.isDisliked;
    update({
      isDisliked: !wasDisliked,
      isLiked: false,
      dislikes: wasDisliked ? local.dislikes - 1 : local.dislikes + 1,
      likes: local.isLiked ? local.likes - 1 : local.likes,
    });
    try {
      await videoApi.dislike(local._id);
    } catch {
      update(video);
    }
  };

  const handleSubscribe = async () => {
    if (!isAuthenticated) { window.location.href = '/login'; return; }
    const channel: any = local.channel;
    const channelId = channel._id;
    setSubLoading(true);
    try {
      if (channel.isSubscribed) {
        await userApi.unsubscribe(channelId);
        update({ channel: { ...channel, isSubscribed: false, subscribersCount: (channel.subscribersCount||1)-1 } } as any);
      } else {
        await userApi.subscribe(channelId);
        update({ channel: { ...channel, isSubscribed: true, subscribersCount: (channel.subscribersCount||0)+1 } } as any);
      }
    } catch {}
    setSubLoading(false);
  };

  const handleShare = async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(()=>setCopied(false), 2000);
    } catch {
      window.prompt('Copy link:', url);
    }
  };

  const handleWatchLater = async () => {
    if (!isAuthenticated) { window.location.href = '/login'; return; }
    try {
      if (local.isInWatchLater) {
        await userApi.removeFromWatchLater(local._id);
        update({ isInWatchLater: false });
      } else {
        await userApi.addToWatchLater(local._id);
        update({ isInWatchLater: true });
      }
    } catch {}
  };

  const channel: any = local.channel;
  const channelName = channel?.channelName || channel?.username || 'Unknown';

  return (
    <div className="py-3">
      <h1 className="text-xl md:text-[20px] font-bold leading-6">{local.title}</h1>
      <div className="flex flex-col md:flex-row md:items-center gap-3 mt-3">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-full bg-zinc-300 dark:bg-zinc-700 shrink-0 overflow-hidden">
            {channel?.avatar ? <img src={channel.avatar} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center font-bold">{channelName[0]?.toUpperCase()}</div>}
          </div>
          <div className="min-w-0">
            <div className="font-medium truncate">{channelName}</div>
            <div className="text-xs text-zinc-500">{formatNumber(channel?.subscribersCount||0)} subscribers</div>
          </div>
          <button onClick={handleSubscribe} disabled={subLoading} className={`ml-4 px-4 py-1.5 rounded-full text-sm font-medium ${channel?.isSubscribed ? 'bg-zinc-100 dark:bg-zinc-800' : 'bg-black text-white dark:bg-white dark:text-black'}`}>
            {channel?.isSubscribed ? 'Subscribed' : 'Subscribe'}
          </button>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto">
          <div className="flex rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
            <button onClick={handleLike} className={`flex items-center gap-2 px-4 py-1.5 text-sm font-medium hover:bg-zinc-200 dark:hover:bg-zinc-700 ${local.isLiked ? 'text-blue-600' : ''}`}>
              👍 {formatNumber(local.likes)}
            </button>
            <div className="w-px bg-zinc-300 dark:bg-zinc-700 my-1" />
            <button onClick={handleDislike} className={`px-3 py-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-700 ${local.isDisliked ? 'text-blue-600' : ''}`}>👎</button>
          </div>
          <button onClick={handleShare} className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-sm font-medium hover:bg-zinc-200 dark:hover:bg-zinc-700">
            {copied ? '✓ Copied' : '↗ Share'}
          </button>
          <button onClick={handleWatchLater} className={`px-4 py-1.5 rounded-full text-sm font-medium ${local.isInWatchLater ? 'bg-black text-white dark:bg-white dark:text-black' : 'bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}>
            {local.isInWatchLater ? '✓ Saved' : '+ Save'}
          </button>
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-zinc-100 dark:bg-[#272727] p-3">
        <div className="flex gap-4 text-sm font-medium">
          <span>{formatNumber(local.views)} views</span>
          <span>{new Date(local.createdAt).toLocaleDateString()}</span>
          {local.tags && <span className="truncate">#{local.tags.slice(0,3).join(' #')}</span>}
        </div>
        <div className={`mt-2 text-sm whitespace-pre-wrap break-words ${!showDesc ? 'line-clamp-2' : ''}`}>
          {local.description || 'No description.'}
        </div>
        <button onClick={()=>setShowDesc(!showDesc)} className="mt-2 text-sm font-medium">{showDesc ? 'Show less' : '...more'}</button>
      </div>
    </div>
  );
}
