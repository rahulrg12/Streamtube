import { useEffect, useRef, useState, useCallback } from 'react';
import { useVideoPlayer } from '../hooks/useVideoPlayer';
import { videoApi } from '../services/api';

interface Props {
  videoId: string;
  src: string;
  hlsSrc?: string;
  poster?: string;
  autoPlay?: boolean;
  onTimeUpdate?: (current: number, duration: number) => void;
}

function formatTime(s: number): string {
  if (!isFinite(s) || isNaN(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}:${String(m % 60).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  return `${m}:${String(sec).padStart(2,'0')}`;
}

export default function VideoPlayer({ videoId, src, hlsSrc, poster, autoPlay, onTimeUpdate }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showControls, setShowControls] = useState(true);
  const [showSpeed, setShowSpeed] = useState(false);
  const hideTimer = useRef<number | null>(null);

  const {
    videoRef,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isFullscreen,
    isBuffering,
    togglePlay,
    seek,
    seekBy,
    changeVolume,
    toggleMute,
    toggleFullscreen,
    changeRate,
    playbackRate,
  } = useVideoPlayer({ hlsUrl: hlsSrc, autoPlay });

  // Keyboard controls
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;
      switch (e.code) {
        case 'Space':
        case 'KeyK':
          e.preventDefault();
          togglePlay();
          break;
        case 'KeyM':
          toggleMute();
          break;
        case 'KeyF':
          toggleFullscreen();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          seekBy(-5);
          break;
        case 'ArrowRight':
          e.preventDefault();
          seekBy(5);
          break;
        case 'ArrowUp':
          e.preventDefault();
          changeVolume(Math.min(1, volume + 0.05));
          break;
        case 'ArrowDown':
          e.preventDefault();
          changeVolume(Math.max(0, volume - 0.05));
          break;
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [togglePlay, toggleMute, toggleFullscreen, seekBy, volume, changeVolume]);

  // Auto-hide controls
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    if (isPlaying) {
      hideTimer.current = window.setTimeout(() => setShowControls(false), 2500);
    }
  }, [isPlaying]);

  useEffect(() => {
    resetHideTimer();
  }, [isPlaying, resetHideTimer]);

  // Report time + track view after 5s
  const viewTracked = useRef(false);
  useEffect(() => {
    if (currentTime > 5 && !viewTracked.current) {
      viewTracked.current = true;
      videoApi.incrementView(videoId).catch(()=>{});
    }
    onTimeUpdate?.(currentTime, duration);
  }, [currentTime, duration, videoId, onTimeUpdate]);

  // Touch handling
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const onTouchStart = (e: React.TouchEvent) => setTouchStartX(e.touches[0].clientX);
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null) return;
    const diff = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(diff) > 60) {
      if (diff > 0) seekBy(-10);
      else seekBy(10);
    }
    setTouchStartX(null);
  };

  const progressPercent = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="relative group bg-black rounded-xl overflow-hidden aspect-video w-full"
      onMouseMove={resetHideTimer}
      onMouseLeave={() => { if (isPlaying) setShowControls(false); }}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      onClick={(e) => {
        const target = e.target as HTMLElement;
        if (target.closest('button') || target.closest('input')) return;
        togglePlay();
      }}
    >
      <video
        ref={videoRef}
        src={hlsSrc ? undefined : src}
        poster={poster}
        className="w-full h-full object-contain"
        playsInline
        preload="metadata"
        crossOrigin="anonymous"
      />

      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-12 h-12 border-4 border-white/30 border-t-white rounded-full animate-spin" />
        </div>
      )}

      {/* Center play button when paused */}
      {!isPlaying && !isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-black/60 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 md:w-10 md:h-10 text-white fill-white ml-1" viewBox="0 0 24 24"><path d="M8 5.14v14l11-7-11-7z"/></svg>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-3 md:p-4 transition-opacity ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        {/* Progress */}
        <div className="relative group/progress mb-3">
          <div className="h-1 bg-white/30 rounded-full cursor-pointer" onClick={(e)=>{
            const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
            const pct = (e.clientX - rect.left) / rect.width;
            seek(pct * duration);
          }}>
            <div className="h-full bg-red-600 rounded-full relative" style={{ width: `${progressPercent}%` }}>
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-red-600 rounded-full opacity-0 group-hover/progress:opacity-100 transition" />
            </div>
          </div>
          <input
            type="range"
            min={0}
            max={duration || 100}
            value={currentTime}
            onChange={(e)=>seek(Number(e.target.value))}
            className="absolute inset-0 opacity-0 cursor-pointer w-full"
          />
        </div>

        <div className="flex items-center justify-between gap-2 text-white">
          <div className="flex items-center gap-2 md:gap-3">
            <button onClick={(e)=>{e.stopPropagation(); togglePlay();}} className="p-1 hover:bg-white/20 rounded-full">
              {isPlaying ? (
                <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              ) : (
                <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24"><path d="M8 5.14v14l11-7-11-7z"/></svg>
              )}
            </button>

            <button onClick={(e)=>{e.stopPropagation(); toggleMute();}} className="p-1 hover:bg-white/20 rounded-full">
              {isMuted || volume===0 ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/></svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072M19.07 4.93a10 10 0 010 14.142M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>
              )}
            </button>

            <div className="hidden md:flex items-center gap-2">
              <input type="range" min={0} max={1} step={0.01} value={isMuted ? 0 : volume} onChange={(e)=>changeVolume(Number(e.target.value))} className="w-20 accent-white" />
            </div>

            <span className="text-sm font-mono">{formatTime(currentTime)} / {formatTime(duration)}</span>
          </div>

          <div className="flex items-center gap-1 md:gap-2">
            <div className="relative">
              <button onClick={(e)=>{e.stopPropagation(); setShowSpeed(!showSpeed);}} className="px-2 py-1 text-xs border border-white/40 rounded hover:bg-white/20">
                {playbackRate}x
              </button>
              {showSpeed && (
                <div className="absolute bottom-10 right-0 bg-black/90 rounded-lg py-1 w-24">
                  {[0.25,0.5,0.75,1,1.25,1.5,1.75,2].map(r=>(
                    <button key={r} onClick={(e)=>{e.stopPropagation(); changeRate(r); setShowSpeed(false);}} className={`w-full text-left px-3 py-1 text-sm hover:bg-white/20 ${playbackRate===r?'text-red-500':''}`}>{r}x</button>
                  ))}
                </div>
              )}
            </div>

            <button onClick={(e)=>{e.stopPropagation(); toggleFullscreen();}} className="p-1 hover:bg-white/20 rounded-full">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isFullscreen ? "M9 9L4 4m0 0l5 0M4 4v5M15 9l5-5m0 0l0 5M20 4v-0M9 15l-5 5m0 0l5 0M4 20v-5M15 15l5 5m0 0l0-5M20 20v-0" : "M4 8V4m0 0h4M4 4l5 5M20 8V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5M20 16v4m0 0h-4m4 0l-5-5"} /></svg>
            </button>
          </div>
        </div>

        <div className="hidden md:flex gap-2 mt-2 text-xs text-white/60">
          <span>Space/K: play</span><span>•</span><span>M: mute</span><span>•</span><span>F: fullscreen</span><span>•</span><span>←→: seek 5s</span>
        </div>
      </div>
    </div>
  );
}
