import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { videoApi } from '../services/api';
import type { Video } from '../types';

function fmtViews(n: number){ if(n>=1e6) return (n/1e6).toFixed(1)+'M'; if(n>=1e3) return (n/1e3).toFixed(1)+'K'; return String(n); }

export default function Recommended({ currentVideoId }: { currentVideoId: string }) {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRelated = async () => {
      setLoading(true);
      try {
        const { data } = await videoApi.getRelated(currentVideoId);
        setVideos(data.videos || data.data || data || []);
      } catch {
        try {
          const { data } = await videoApi.getAll({ limit: 12 });
          setVideos((data.videos || data.data || []).filter((v: Video) => v._id !== currentVideoId));
        } catch {
          setVideos([]);
        }
      }
      setLoading(false);
    };
    fetchRelated();
  }, [currentVideoId]);

  if (loading) {
    return <div className="space-y-3">{[1,2,3,4].map(i=><div key={i} className="h-24 bg-zinc-800 rounded-xl animate-pulse" />)}</div>;
  }

  return (
    <div className="space-y-3">
      {videos.map(v => {
        const ch: any = v.channel;
        return (
          <Link key={v._id} to={`/watch/${v._id}`} className="flex gap-2 group">
            <div className="w-[168px] aspect-video rounded-lg overflow-hidden bg-zinc-900 shrink-0">
              <img src={v.thumbnailUrl} alt="" className="w-full h-full object-cover group-hover:scale-105 transition" loading="lazy" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium line-clamp-2 leading-tight group-hover:text-blue-500">{v.title}</div>
              <div className="text-xs text-zinc-500 mt-1 truncate">{ch?.channelName || ch?.username}</div>
              <div className="text-xs text-zinc-500">{fmtViews(v.views)} views • {new Date(v.createdAt).toLocaleDateString()}</div>
            </div>
          </Link>
        );
      })}
      {videos.length===0 && <div className="text-sm text-zinc-500">No related videos</div>}
    </div>
  );
}
