import { Link, useLocation } from 'react-router-dom';
import { useUIStore } from '../stores/useUIStore';
import { useEffect } from 'react';
import { CATEGORIES } from '../types';

const primaryLinks = [
  { label: 'Home', icon: '🏠', path: '/' },
  { label: 'History', icon: '🕘', path: '/history' },
  { label: 'Watch Later', icon: '⏱', path: '/watch-later' },
];

export default function Sidebar() {
  const { sidebarOpen, setSidebar, isMobile, setIsMobile } = useUIStore();
  const location = useLocation();

  useEffect(() => {
    const check = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      if (mobile) setSidebar(false);
      else setSidebar(true);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, [setIsMobile, setSidebar]);

  if (isMobile && sidebarOpen) {
    return (
      <>
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={()=>setSidebar(false)} />
        <aside className="fixed left-0 top-0 bottom-0 w-[240px] bg-white dark:bg-[#0f0f0f] z-40 overflow-y-auto pt-14 px-3">
          <nav className="py-2">
            {primaryLinks.map(l => (
              <Link key={l.path} to={l.path} onClick={()=>setSidebar(false)} className={`flex items-center gap-5 px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 ${location.pathname===l.path ? 'bg-zinc-100 dark:bg-zinc-800 font-medium' : ''}`}>
                <span className="text-[20px]">{l.icon}</span>{l.label}
              </Link>
            ))}
            <hr className="my-3 border-zinc-200 dark:border-zinc-800" />
            <div className="px-3 py-2 font-semibold text-sm">Explore</div>
            {CATEGORIES.slice(1,8).map(c => (
              <Link key={c} to={`/?category=${encodeURIComponent(c)}`} onClick={()=>setSidebar(false)} className="flex items-center gap-5 px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">
                <span className="w-6">•</span>{c}
              </Link>
            ))}
          </nav>
        </aside>
      </>
    );
  }

  if (!sidebarOpen) {
    return (
      <aside className="hidden lg:block sticky top-14 h-[calc(100vh-56px)] w-[72px] shrink-0 overflow-y-auto px-1 py-3">
        {primaryLinks.map(l => (
          <Link key={l.path} to={l.path} className={`flex flex-col items-center gap-1 py-4 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-[10px] ${location.pathname===l.path ? 'bg-zinc-100 dark:bg-zinc-800' : ''}`}>
            <span className="text-xl">{l.icon}</span>{l.label.split(' ')[0]}
          </Link>
        ))}
      </aside>
    );
  }

  return (
    <aside className="hidden lg:block sticky top-14 h-[calc(100vh-56px)] w-[240px] shrink-0 overflow-y-auto px-3 py-3">
      <nav>
        {primaryLinks.map(l => (
          <Link key={l.path} to={l.path} className={`flex items-center gap-5 px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 ${location.pathname===l.path ? 'bg-zinc-100 dark:bg-zinc-800 font-medium' : ''}`}>
            <span className="text-[20px]">{l.icon}</span>{l.label}
          </Link>
        ))}
        <hr className="my-3 border-zinc-200 dark:border-zinc-800" />
        <div className="px-3 py-2 font-semibold">Explore</div>
        {CATEGORIES.slice(1).map(c => (
          <Link key={c} to={`/?category=${encodeURIComponent(c)}`} className="flex items-center gap-5 px-3 py-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-sm">
            <span>•</span>{c}
          </Link>
        ))}
        <hr className="my-3 border-zinc-200 dark:border-zinc-800" />
        <div className="px-3 text-xs text-zinc-500">© 2025 StreamTube<br/>Telegram ingest • Range streaming</div>
      </nav>
    </aside>
  );
}
