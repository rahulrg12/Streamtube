import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/useAuthStore';
import { useThemeStore } from '../stores/useThemeStore';
import { useUIStore } from '../stores/useUIStore';

export default function Navbar() {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { theme, toggle } = useThemeStore();
  const { toggleSidebar } = useUIStore();
  const [q, setQ] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setShowMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    navigate(`/search?q=${encodeURIComponent(q.trim())}`);
    setShowMobileSearch(false);
  };

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-2 bg-white/95 backdrop-blur dark:bg-[#0f0f0f]/95 px-3 md:px-4 border-b border-zinc-200 dark:border-zinc-800">
      <button onClick={toggleSidebar} className="p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>

      <Link to="/" className="flex items-center gap-1 shrink-0">
        <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
          <svg className="w-5 h-5 text-white fill-white" viewBox="0 0 24 24"><path d="M8 5.14v14l11-7-11-7z"/></svg>
        </div>
        <span className="hidden sm:block font-bold text-[20px] tracking-tight ml-1">StreamTube</span>
      </Link>

      {/* Desktop search */}
      <form onSubmit={onSearch} className="hidden md:flex flex-1 max-w-[640px] mx-auto items-center">
        <div className="flex flex-1">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search"
            className="w-full h-10 rounded-l-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-4 focus:outline-none focus:border-blue-500"
          />
          <button type="submit" className="h-10 w-16 rounded-r-full bg-zinc-100 dark:bg-zinc-800 border border-l-0 border-zinc-300 dark:border-zinc-700 hover:bg-zinc-200 dark:hover:bg-zinc-700 flex items-center justify-center">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </button>
        </div>
      </form>

      {/* Mobile */}
      <div className="md:hidden flex-1" />
      <button onClick={() => setShowMobileSearch(v=>!v)} className="md:hidden p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
      </button>

      <button onClick={toggle} className="p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800" title={`Switch to ${theme==='dark'?'light':'dark'}`}>
        {theme==='dark' ? (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
        ) : (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
        )}
      </button>

      {isAuthenticated ? (
        <div className="relative" ref={menuRef}>
          <button onClick={() => setShowMenu(!showMenu)} className="w-8 h-8 rounded-full overflow-hidden bg-zinc-300">
            {user?.avatar ? <img src={user.avatar} alt="avatar" className="w-full h-full object-cover" /> : <span className="flex h-full w-full items-center justify-center font-bold">{user?.username?.[0]?.toUpperCase()}</span>}
          </button>
          {showMenu && (
            <div className="absolute right-0 top-10 w-72 rounded-xl bg-white dark:bg-[#212121] shadow-2xl border border-zinc-200 dark:border-zinc-700 overflow-hidden py-2 z-50">
              <div className="flex gap-3 px-4 py-3 border-b border-zinc-200 dark:border-zinc-700">
                <div className="w-10 h-10 rounded-full bg-zinc-300 flex items-center justify-center shrink-0">{user?.username?.[0]?.toUpperCase()}</div>
                <div className="min-w-0">
                  <div className="font-medium truncate">{user?.username}</div>
                  <div className="text-sm text-zinc-500 truncate">{user?.email}</div>
                </div>
              </div>
              <Link to="/history" onClick={()=>setShowMenu(false)} className="flex gap-4 px-4 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800"><span>🕘</span> History</Link>
              <Link to="/watch-later" onClick={()=>setShowMenu(false)} className="flex gap-4 px-4 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800"><span>⏱</span> Watch later</Link>
              {user?.role==='admin' && <Link to="/admin" onClick={()=>setShowMenu(false)} className="flex gap-4 px-4 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800"><span>⚙️</span> Admin Dashboard</Link>}
              <button onClick={async()=>{ await logout(); setShowMenu(false); navigate('/'); }} className="w-full text-left flex gap-4 px-4 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800">🚪 Sign out</button>
            </div>
          )}
        </div>
      ) : (
        <Link to="/login" className="border border-zinc-300 dark:border-zinc-600 rounded-full px-4 py-1.5 text-sm font-medium text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950 flex items-center gap-2">
          <span className="w-6 h-6 rounded-full border border-blue-500 flex items-center justify-center">👤</span> Sign in
        </Link>
      )}

      {showMobileSearch && (
        <div className="absolute inset-0 bg-white dark:bg-[#0f0f0f] flex items-center gap-2 px-3 z-50 md:hidden">
          <button onClick={()=>setShowMobileSearch(false)} className="p-2"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></button>
          <form onSubmit={onSearch} className="flex-1 flex">
            <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Search StreamTube" className="flex-1 h-10 rounded-full bg-zinc-100 dark:bg-zinc-800 px-4 focus:outline-none" />
          </form>
        </div>
      )}
    </header>
  );
}
