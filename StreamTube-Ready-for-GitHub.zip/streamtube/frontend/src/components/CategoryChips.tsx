import { CATEGORIES } from '../types';

interface Props {
  selected: string;
  onSelect: (cat: string) => void;
}

export default function CategoryChips({ selected, onSelect }: Props) {
  return (
    <div className="sticky top-14 z-20 bg-white dark:bg-[#0f0f0f] border-b border-zinc-200 dark:border-zinc-800">
      <div className="flex gap-2 overflow-x-auto scrollbar-none px-4 py-3 whitespace-nowrap">
        {CATEGORIES.map((cat) => {
          const active = selected === cat || (selected === '' && cat === 'All');
          return (
            <button
              key={cat}
              onClick={() => onSelect(cat === 'All' ? '' : cat)}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition ${active ? 'bg-black text-white dark:bg-white dark:text-black' : 'bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}
            >
              {cat}
            </button>
          );
        })}
      </div>
    </div>
  );
}
