import { Link } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import type { Video } from '../types';

function formatViews(n: number): string {
  if (n >= 1_000_000) return `${(n/1_000_000).toFixed(1).replace(/\.0$/,'')}M views`;
  if (n >= 1_000) return `${(n/1_000).toFixed(1).replace(/\.0$/,'')}K views`;
  return `${n} views`;
}
function formatDuration(sec: number): string {
  if (!sec) return '';
  const m = Math.floor(sec/60);
  const s = Math.floor(sec%60);
  const h = Math.floor(m/60);
  if (h>0) return `${h}:${String(m%60).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${m}:${String(s).padStart(2,'0')}`;
}
function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff/60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins/60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours/24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days/30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months/12)}y ago`;
}

export default function VideoCard({ video }: { video: Video }) {
  const [loaded, setLoaded] = useState(false);
  const [inView, setInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setInView(true); obs.disconnect(); } }, { rootMargin: '300px' });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const channel = video.channel as any;
  const channelName = channel?.channelName || channel?.username || 'Unknown';

  return (
    <div ref={ref} className="group">
      <Link to={`/watch/${video._id}`} className="block">
        <div className="relative aspect-video rounded-xl overflow-hidden bg-zinc-900">
          {!loaded && <div className="absolute inset-0 shimmer" />}
          {inView && (
            <img
              src={video.thumbnailUrl}
              alt={video.title}
              loading="lazy"
              onLoad={()=>setLoaded(true)}
              onError={()=>setLoaded(true)}
              className={`w-full h-full object-cover transition duration-300 group-hover:scale-[1.02] ${loaded ? 'opacity-100' : 'opacity-0'}`}
            />
          )}
          {video.duration > 0 && (
            <span className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">{formatDuration(video.duration)}</span>
          )}
        </div>
      </Link>
      <div className="flex gap-3 pt-3">
        <div className="w-9 h-9 rounded-full bg-zinc-300 dark:bg-zinc-700 shrink-0 overflow-hidden mt-0.5">
          {channel?.avatar ? <img src={channel.avatar} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-sm font-bold">{channelName[0]?.toUpperCase()}</div>}
        </div>
        <div className="min-w-0 flex-1">
          <Link to={`/watch/${video._id}`} className="font-medium leading-[1.35] line-clamp-2 text-[15px] group-hover:text-blue-600 dark:group-hover:text-blue-400">{video.title}</Link>
          <div className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">
            <div className="truncate hover:text-zinc-900 dark:hover:text-white">{channelName}</div>
            <div className="flex gap-1 items-center text-xs sm:text-sm">
              <span>{formatViews(video.views)}</span><span>•</span><span>{timeAgo(video.createdAt)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
