import { useState, useEffect } from 'react';
import { commentApi } from '../services/api';
import { useAuthStore } from '../stores/useAuthStore';
import type { Comment } from '../types';

export default function CommentsSection({ videoId }: { videoId: string }) {
  const { user, isAuthenticated } = useAuthStore();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [newText, setNewText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  const fetchComments = async () => {
    setLoading(true);
    try {
      const { data } = await commentApi.getByVideo(videoId);
      setComments(data.comments || data.data || data || []);
    } catch {
      setComments([]);
    }
    setLoading(false);
  };

  useEffect(() => { fetchComments(); }, [videoId]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    if (!isAuthenticated) { window.location.href = '/login'; return; }
    setSubmitting(true);
    try {
      const { data } = await commentApi.create(videoId, newText);
      const created = data.comment || data;
      setComments(prev => [created, ...prev]);
      setNewText('');
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to post comment');
    }
    setSubmitting(false);
  };

  const handleUpdate = async (id: string) => {
    if (!editText.trim()) return;
    try {
      const { data } = await commentApi.update(id, editText);
      const updated = data.comment || data;
      setComments(prev => prev.map(c => c._id === id ? { ...c, ...updated, text: editText } : c));
      setEditingId(null);
    } catch {
      alert('Failed to update');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this comment?')) return;
    try {
      await commentApi.delete(id);
      setComments(prev => prev.filter(c => c._id !== id));
    } catch {
      alert('Failed to delete');
    }
  };

  return (
    <div className="mt-6">
      <h3 className="text-xl font-bold mb-4">{comments.length} Comments</h3>

      {isAuthenticated ? (
        <form onSubmit={handleCreate} className="flex gap-3 mb-6">
          <div className="w-10 h-10 rounded-full bg-zinc-300 dark:bg-zinc-700 flex items-center justify-center shrink-0 font-bold">{user?.username?.[0]?.toUpperCase()}</div>
          <div className="flex-1">
            <input
              value={newText}
              onChange={e=>setNewText(e.target.value)}
              placeholder="Add a comment..."
              className="w-full bg-transparent border-b border-zinc-300 dark:border-zinc-600 py-1 focus:outline-none focus:border-white"
            />
            <div className="flex justify-end gap-2 mt-3">
              <button type="button" onClick={()=>setNewText('')} className="px-4 py-1.5 rounded-full text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800">Cancel</button>
              <button disabled={submitting || !newText.trim()} className="px-4 py-1.5 rounded-full bg-blue-600 text-white text-sm disabled:opacity-50">Comment</button>
            </div>
          </div>
        </form>
      ) : (
        <div className="mb-6 text-sm">Please <a href="/login" className="text-blue-500">sign in</a> to comment.</div>
      )}

      {loading ? (
        <div className="space-y-4">
          {[1,2,3].map(i=>(
            <div key={i} className="flex gap-3 animate-pulse">
              <div className="w-10 h-10 rounded-full bg-zinc-800" />
              <div className="flex-1 space-y-2"><div className="h-4 bg-zinc-800 rounded w-1/4"/><div className="h-3 bg-zinc-800 rounded w-3/4"/></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-5">
          {comments.map(c => (
            <div key={c._id} className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-zinc-300 dark:bg-zinc-700 shrink-0 overflow-hidden flex items-center justify-center font-bold text-sm">
                {c.user?.avatar ? <img src={c.user.avatar} alt="" className="w-full h-full object-cover" /> : c.user?.username?.[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-medium">@{c.user?.username}</span>
                  <span className="text-xs text-zinc-500">{new Date(c.createdAt).toLocaleDateString()} {c.isEdited && '(edited)'}</span>
                </div>
                {editingId === c._id ? (
                  <div className="mt-1">
                    <input value={editText} onChange={e=>setEditText(e.target.value)} className="w-full bg-zinc-100 dark:bg-zinc-800 rounded px-2 py-1 text-sm" autoFocus />
                    <div className="flex gap-2 mt-2">
                      <button onClick={()=>setEditingId(null)} className="text-xs px-3 py-1 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800">Cancel</button>
                      <button onClick={()=>handleUpdate(c._id)} className="text-xs px-3 py-1 rounded-full bg-blue-600 text-white">Save</button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm mt-1 whitespace-pre-wrap break-words">{c.text}</p>
                )}
                {(c.isOwn || c.user?._id === user?._id) && editingId !== c._id && (
                  <div className="flex gap-3 mt-2 text-xs">
                    <button onClick={()=>{ setEditingId(c._id); setEditText(c.text); }} className="text-zinc-500 hover:text-white">Edit</button>
                    <button onClick={()=>handleDelete(c._id)} className="text-zinc-500 hover:text-red-400">Delete</button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {comments.length===0 && <div className="text-center text-zinc-500 py-8">No comments yet. Be first!</div>}
        </div>
      )}
    </div>
  );
}
