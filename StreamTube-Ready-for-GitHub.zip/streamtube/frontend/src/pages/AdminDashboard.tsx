import { useEffect, useState } from 'react';
import { adminApi, videoApi } from '../services/api';
import type { SyncLog, Video, TelegramConfig } from '../types';

export default function AdminDashboard() {
  const [config, setConfig] = useState<TelegramConfig>({ mode: 'bot' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [syncingHistory, setSyncingHistory] = useState(false);
  const [syncingNew, setSyncingNew] = useState(false);
  const [logs, setLogs] = useState<SyncLog[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [msg, setMsg] = useState<{type:'success'|'error', text:string}|null>(null);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [cfgRes, logsRes, videosRes] = await Promise.allSettled([
        adminApi.getTelegramConfig(),
        adminApi.getLogs(),
        adminApi.getAllVideos({ limit: 20, sort: 'newest' }),
      ]);
      if (cfgRes.status==='fulfilled') {
        setConfig(cfgRes.value.data.config || cfgRes.value.data || { mode: 'bot' });
      }
      if (logsRes.status==='fulfilled') {
        setLogs(logsRes.value.data.logs || logsRes.value.data || []);
      }
      if (videosRes.status==='fulfilled') {
        setVideos(videosRes.value.data.videos || videosRes.value.data || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const saveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg(null);
    try {
      await adminApi.saveTelegramConfig(config);
      setMsg({ type:'success', text:'Configuration saved'});
    } catch (err: any) {
      setMsg({ type:'error', text: err.response?.data?.message || 'Failed to save'});
    }
    setSaving(false);
  };

  const testConn = async () => {
    setTesting(true);
    setMsg(null);
    try {
      const { data } = await adminApi.testConnection();
      setMsg({ type:'success', text: data.message || 'Connection successful'});
      fetchAll();
    } catch (err: any) {
      setMsg({ type:'error', text: err.response?.data?.message || 'Test failed'});
    }
    setTesting(false);
  };

  const syncHistory = async () => {
    if (!confirm('History sync requires MTProto (api_id, api_hash, user session). Bot API cannot fetch history. Continue?')) return;
    setSyncingHistory(true);
    setMsg(null);
    try {
      const { data } = await adminApi.syncHistory();
      setMsg({ type:'success', text: data.message || `History sync started: ${data.count||0} videos`});
      fetchAll();
    } catch (err: any) {
      setMsg({ type:'error', text: err.response?.data?.message || 'History sync failed - ensure MTProto creds are set'});
    }
    setSyncingHistory(false);
  };

  const syncNew = async () => {
    setSyncingNew(true);
    setMsg(null);
    try {
      const { data } = await adminApi.syncNew();
      setMsg({ type:'success', text: data.message || `Sync new: ${data.count||0} videos`});
      fetchAll();
    } catch (err: any) {
      setMsg({ type:'error', text: err.response?.data?.message || 'Sync failed'});
    }
    setSyncingNew(false);
  };

  const handleDeleteVideo = async (id: string) => {
    if (!confirm('Delete this video?')) return;
    try {
      await videoApi.delete(id);
      setVideos(v=>v.filter(x=>x._id!==id));
    } catch {
      alert('Delete failed');
    }
  };

  if (loading) return <div className="p-6"><div className="h-64 bg-zinc-800 rounded-xl animate-pulse" /></div>;

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      {msg && <div className={`p-3 rounded-lg text-sm ${msg.type==='success' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300'}`}>{msg.text}</div>}

      {/* Telegram API honesty notice */}
      <div className="rounded-xl border border-yellow-600/50 bg-yellow-50 dark:bg-yellow-950/30 p-4 text-sm">
        <div className="font-bold text-yellow-800 dark:text-yellow-300">⚠️ Telegram API Limits - Important</div>
        <ul className="list-disc list-outside ml-5 mt-2 space-y-1 text-yellow-800 dark:text-yellow-200/80">
          <li><strong>Bot API</strong> (bot token) cannot fetch channel history. It only receives NEW messages via webhook/long-polling if bot is admin in channel. Use for sync new only.</li>
          <li><strong>History sync</strong> requires <strong>MTProto</strong>: api_id + api_hash from https://my.telegram.org + user session string (Telethon / Pyrogram). User must be participant of channel.</li>
          <li>Streaming endpoint must support <code>Range: bytes=...</code> headers and respond with <code>206 Partial Content</code> for seeking. Backend should expose <code>/api/videos/:id/stream</code>.</li>
          <li>HLS fallback: backend can generate <code>/api/videos/:id/hls/index.m3u8</code> for adaptive streaming via hls.js.</li>
        </ul>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <form onSubmit={saveConfig} className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-4 bg-white dark:bg-[#212121]">
          <h2 className="font-bold text-lg">Telegram Configuration</h2>

          <div className="flex gap-2 text-sm">
            <button type="button" onClick={()=>setConfig(c=>({...c, mode:'bot'}))} className={`px-4 py-1.5 rounded-full ${config.mode==='bot' ? 'bg-black text-white dark:bg-white dark:text-black' : 'bg-zinc-100 dark:bg-zinc-800'}`}>Bot Mode (new only)</button>
            <button type="button" onClick={()=>setConfig(c=>({...c, mode:'mtproto'}))} className={`px-4 py-1.5 rounded-full ${config.mode==='mtproto' ? 'bg-black text-white dark:bg-white dark:text-black' : 'bg-zinc-100 dark:bg-zinc-800'}`}>MTProto Mode (history + new)</button>
          </div>

          <div>
            <label className="text-sm font-medium">Bot Token {config.mode==='bot' ? '' : '(optional if using MTProto)'}</label>
            <input value={config.botToken||''} onChange={e=>setConfig({...config, botToken:e.target.value})} placeholder="123456:ABC-DEF..." className="mt-1 w-full h-10 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-3 text-sm" />
            <p className="text-xs text-zinc-500 mt-1">For sync new messages only. Bot must be admin in channel.</p>
          </div>

          <div>
            <label className="text-sm font-medium">Channel / Chat ID</label>
            <input value={config.channelId||''} onChange={e=>setConfig({...config, channelId:e.target.value})} placeholder="@mychannel or -1001234567890" className="mt-1 w-full h-10 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-3 text-sm" />
          </div>

          {config.mode==='mtproto' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">API ID</label>
                  <input value={config.apiId||''} onChange={e=>setConfig({...config, apiId:e.target.value})} placeholder="123456" className="mt-1 w-full h-10 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-3 text-sm" />
                </div>
                <div>
                  <label className="text-sm font-medium">API Hash</label>
                  <input value={config.apiHash||''} onChange={e=>setConfig({...config, apiHash:e.target.value})} placeholder="abc123..." className="mt-1 w-full h-10 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-3 text-sm" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Session String (user session)</label>
                <textarea value={config.sessionString||''} onChange={e=>setConfig({...config, sessionString:e.target.value})} placeholder="1A2B3C... (Telethon StringSession)" rows={3} className="mt-1 w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#121212] px-3 py-2 text-sm font-mono" />
                <p className="text-xs text-zinc-500 mt-1">Generate via Telethon: StringSession.save(). Keep secret!</p>
              </div>
            </>
          )}

          <div className="flex gap-2">
            <button disabled={saving} type="submit" className="px-5 py-2 rounded-full bg-black text-white dark:bg-white dark:text-black text-sm font-medium disabled:opacity-50">{saving ? 'Saving...' : 'Save Config'}</button>
            <button type="button" onClick={testConn} disabled={testing} className="px-5 py-2 rounded-full bg-zinc-100 dark:bg-zinc-800 text-sm font-medium disabled:opacity-50">{testing ? 'Testing...' : 'Test Connection'}</button>
          </div>

          {config.isConnected !== undefined && (
            <div className={`text-sm ${config.isConnected ? 'text-green-600' : 'text-red-500'}`}>{config.isConnected ? '● Connected' : '● Not connected'} {config.lastSync && `• Last sync: ${new Date(config.lastSync).toLocaleString()}`}</div>
          )}
        </form>

        <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 bg-white dark:bg-[#212121] space-y-4">
          <h2 className="font-bold text-lg">Sync Controls</h2>
          <div className="space-y-3">
            <button onClick={syncHistory} disabled={syncingHistory} className="w-full h-11 rounded-lg bg-orange-600 text-white font-medium disabled:opacity-50 text-sm">
              {syncingHistory ? 'Syncing history...' : 'Sync History (MTProto required)'}
            </button>
            <p className="text-xs text-zinc-500">Fetches all existing videos from channel using MTProto. Bot API cannot do this.</p>
            <button onClick={syncNew} disabled={syncingNew} className="w-full h-11 rounded-lg bg-red-600 text-white font-medium disabled:opacity-50 text-sm">
              {syncingNew ? 'Syncing...' : 'Sync New Messages'}
            </button>
            <p className="text-xs text-zinc-500">Checks for new Telegram messages and ingests them. Works with Bot + MTProto.</p>
          </div>

          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800">
            <h3 className="font-medium mb-2">Logs</h3>
            <div className="max-h-[260px] overflow-y-auto rounded-lg bg-black/5 dark:bg-black/30 p-2">
              <table className="w-full text-xs">
                <thead><tr className="text-left text-zinc-500"><th>Type</th><th>Status</th><th>Message</th><th>Time</th></tr></thead>
                <tbody>
                  {logs.map(log => (
                    <tr key={log._id} className="border-t border-zinc-200 dark:border-zinc-800">
                      <td className="py-1.5">{log.type}</td>
                      <td className={`py-1.5 ${log.status==='success' ? 'text-green-500' : log.status==='failed' ? 'text-red-500' : 'text-yellow-500'}`}>{log.status}</td>
                      <td className="py-1.5 truncate max-w-[180px]">{log.message}</td>
                      <td className="py-1.5">{new Date(log.createdAt).toLocaleTimeString()}</td>
                    </tr>
                  ))}
                  {logs.length===0 && <tr><td colSpan={4} className="text-center py-4 text-zinc-500">No logs yet</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 bg-white dark:bg-[#212121]">
        <h2 className="font-bold text-lg mb-4">Video Management ({videos.length})</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left border-b border-zinc-200 dark:border-zinc-800 text-zinc-500"><th className="pb-2">Thumbnail</th><th>Title</th><th>Views</th><th>Category</th><th>Created</th><th>Actions</th></tr></thead>
            <tbody>
              {videos.map(v=>(
                <tr key={v._id} className="border-b border-zinc-100 dark:border-zinc-800">
                  <td className="py-2"><img src={v.thumbnailUrl} alt="" className="w-16 aspect-video rounded object-cover" /></td>
                  <td className="py-2 truncate max-w-[300px]">{v.title}</td>
                  <td className="py-2">{v.views}</td>
                  <td className="py-2">{v.category}</td>
                  <td className="py-2 text-xs">{new Date(v.createdAt).toLocaleDateString()}</td>
                  <td className="py-2"><button onClick={()=>handleDeleteVideo(v._id)} className="text-red-500 hover:underline text-xs">Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {videos.length===0 && <div className="text-center py-8 text-zinc-500">No videos</div>}
        </div>
      </div>
    </div>
  );
}
