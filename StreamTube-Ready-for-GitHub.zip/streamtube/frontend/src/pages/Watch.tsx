import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { videoApi, userApi } from '../services/api';
import type { Video } from '../types';
import VideoPlayer from '../components/VideoPlayer';
import VideoInfo from '../components/VideoInfo';
import Comments from '../components/Comments';
import Recommended from '../components/Recommended';

export default function Watch() {
  const { id } = useParams<{ id: string }>();
  const [video, setVideo] = useState<Video | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    const fetch = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data } = await videoApi.getById(id);
        const v = data.video || data;
        setVideo(v);
        // add to history
        userApi.addToHistory(id).catch(()=>{});
        document.title = `${v.title} - StreamTube`;
      } catch (e: any) {
        setError(e.response?.data?.message || 'Video not found');
      }
      setLoading(false);
    };
    fetch();
  }, [id]);

  if (loading) {
    return (
      <div className="flex flex-col lg:flex-row gap-6 p-4">
        <div className="flex-1">
          <div className="aspect-video bg-zinc-900 rounded-xl animate-pulse" />
          <div className="mt-4 space-y-3">
            <div className="h-6 bg-zinc-800 rounded w-3/4" />
            <div className="h-4 bg-zinc-800 rounded w-1/2" />
          </div>
        </div>
        <div className="w-full lg:w-[400px] space-y-3">
          {[1,2,3].map(i=><div key={i} className="h-24 bg-zinc-800 rounded-xl animate-pulse" />)}
        </div>
      </div>
    );
  }

  if (error || !video) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="text-6xl mb-4">😕</div>
        <div className="text-xl font-bold">{error || 'Video not found'}</div>
        <p className="text-zinc-500 mt-2">The video may have been removed or is unavailable.</p>
      </div>
    );
  }

  const streamUrl = videoApi.getStreamUrl(video._id);
  const hlsUrl = video.hlsUrl || videoApi.getHlsUrl(video._id);

  return (
    <div className="flex flex-col lg:flex-row gap-0 lg:gap-6 p-0 lg:p-6 max-w-[2000px] mx-auto">
      <div className="flex-1 min-w-0">
        <VideoPlayer videoId={video._id} src={streamUrl} hlsSrc={video.hlsUrl ? hlsUrl : undefined} poster={video.thumbnailUrl} autoPlay={false} />
        <div className="px-4 lg:px-0">
          <VideoInfo video={video} onUpdate={setVideo} />
          <Comments videoId={video._id} />
        </div>
      </div>
      <div className="w-full lg:w-[402px] shrink-0 px-4 lg:px-0 mt-4 lg:mt-0">
        <Recommended currentVideoId={video._id} />
      </div>
    </div>
  );
}
