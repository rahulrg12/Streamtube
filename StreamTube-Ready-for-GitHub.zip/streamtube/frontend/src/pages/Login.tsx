import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../stores/useAuthStore';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading, error } = useAuthStore();
  const [localError, setLocalError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as any)?.from?.pathname || '/';

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    if (!email || !password) { setLocalError('Please fill all fields'); return; }
    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (err: any) {
      setLocalError(err.message);
    }
  };

  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-10 bg-white dark:bg-[#0f0f0f]">
      <div className="w-full max-w-[400px] border border-zinc-200 dark:border-zinc-800 rounded-xl p-8 bg-white dark:bg-[#212121]">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center mb-3">
            <svg className="w-7 h-7 text-white fill-white" viewBox="0 0 24 24"><path d="M8 5.14v14l11-7-11-7z"/></svg>
          </div>
          <h1 className="text-2xl font-bold">Sign in to StreamTube</h1>
        </div>

        {(error || localError) && <div className="mb-4 p-3 rounded-lg bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 text-sm">{localError || error}</div>}

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" className="mt-1 w-full h-11 rounded-lg border border-zinc-300 dark:border-zinc-600 bg-white dark:bg-[#121212] px-4 focus:outline-none focus:border-blue-500" required />
          </div>
          <div>
            <label className="text-sm font-medium">Password</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" className="mt-1 w-full h-11 rounded-lg border border-zinc-300 dark:border-zinc-600 bg-white dark:bg-[#121212] px-4 focus:outline-none focus:border-blue-500" required />
          </div>
          <button disabled={isLoading} type="submit" className="w-full h-11 rounded-full bg-black text-white dark:bg-white dark:text-black font-medium disabled:opacity-50 hover:opacity-90">
            {isLoading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <div className="mt-6 text-center text-sm">
          Don't have an account? <Link to="/register" className="text-blue-600 hover:underline">Sign up</Link>
        </div>
        <div className="mt-6 pt-6 border-t border-zinc-200 dark:border-zinc-700 text-xs text-zinc-500">
          Backend must support <code>/api/auth/login</code> with cookie + CORS credentials. Streaming endpoint supports Range headers.
        </div>
      </div>
    </div>
  );
}
