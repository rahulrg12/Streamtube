import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { userApi } from '../services/api';
import type { Video } from '../types';
import VideoCard from '../components/VideoCard';

export default function History() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const { data } = await userApi.getHistory();
      setVideos(data.videos || data.history || data.data || []);
    } catch {
      setVideos([]);
    }
    setLoading(false);
  };

  useEffect(() => { fetchHistory(); }, []);

  const clearAll = async () => {
    if (!confirm('Clear entire watch history?')) return;
    try {
      await userApi.clearHistory();
      setVideos([]);
    } catch {
      alert('Failed to clear');
    }
  };

  const removeOne = async (id: string) => {
    try {
      await userApi.removeFromHistory(id);
      setVideos(v => v.filter(x => x._id !== id));
    } catch {}
  };

  return (
    <div className="p-4 md:p-6 max-w-[1800px] mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Watch History</h1>
        {videos.length>0 && <button onClick={clearAll} className="text-sm px-4 py-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700">Clear all history</button>}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({length:8}).map((_,i)=><div key={i} className="aspect-video bg-zinc-800 rounded-xl animate-pulse"/>)}
        </div>
      ) : videos.length===0 ? (
        <div className="text-center py-20">
          <div className="text-5xl mb-4">🕘</div>
          <p className="text-zinc-500">No watch history yet.</p>
          <Link to="/" className="mt-4 inline-block px-6 py-2 bg-black text-white dark:bg-white dark:text-black rounded-full">Browse videos</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
          {videos.map(v=>(
            <div key={v._id} className="relative group">
              <VideoCard video={v} />
              <button onClick={()=>removeOne(v._id)} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/70 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition">✕</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
