import { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { videoApi } from '../services/api';
import type { Video } from '../types';
import VideoCard from '../components/VideoCard';
import CategoryChips from '../components/CategoryChips';
import { useInfiniteScroll } from '../hooks/useInfiniteScroll';

export default function Home() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCat = searchParams.get('category') || '';
  const [category, setCategory] = useState(initialCat);
  const [sort] = useState('newest');
  const [videos, setVideos] = useState<Video[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const loadingRef = useRef(false);

  const fetchVideos = useCallback(async (pageNum: number, cat: string, replace = false) => {
    if (loadingRef.current) return;
    loadingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const params: any = { page: pageNum, limit: 24, sort };
      if (cat) params.category = cat;
      const { data } = await videoApi.getAll(params);
      const newVideos: Video[] = data.videos || data.data || [];
      const more = data.hasMore ?? newVideos.length === 24;
      setVideos(prev => replace ? newVideos : [...prev, ...newVideos]);
      setHasMore(more);
      setPage(pageNum);
    } catch (e: any) {
      setError(e.response?.data?.message || e.message || 'Failed to load videos');
    }
    setLoading(false);
    setInitialLoading(false);
    loadingRef.current = false;
  }, [sort]);

  useEffect(() => {
    setVideos([]);
    setPage(1);
    setHasMore(true);
    setInitialLoading(true);
    fetchVideos(1, category, true);
  }, [category]); // eslint-disable-line

  useEffect(() => {
    if (initialCat !== category) {
      setCategory(initialCat);
    }
  }, [initialCat]);

  const handleCategorySelect = (cat: string) => {
    setCategory(cat);
    if (cat) setSearchParams({ category: cat });
    else setSearchParams({});
  };

  const loadMore = useCallback(() => {
    if (!hasMore || loadingRef.current) return;
    fetchVideos(page + 1, category);
  }, [hasMore, page, category, fetchVideos]);

  const { ref } = useInfiniteScroll(loadMore, { enabled: hasMore && !loading });

  return (
    <div>
      <CategoryChips selected={category} onSelect={handleCategorySelect} />
      <div className="p-2 md:p-4">
        {initialLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-video bg-zinc-200 dark:bg-zinc-800 rounded-xl" />
                <div className="flex gap-3 mt-3">
                  <div className="w-9 h-9 rounded-full bg-zinc-200 dark:bg-zinc-800" />
                  <div className="flex-1 space-y-2"><div className="h-4 bg-zinc-200 dark:bg-zinc-800 rounded w-3/4" /><div className="h-3 bg-zinc-200 dark:bg-zinc-800 rounded w-1/2" /></div>
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-20">
            <p className="text-red-500 mb-4">{error}</p>
            <button onClick={() => fetchVideos(1, category, true)} className="px-6 py-2 bg-red-600 text-white rounded-full">Retry</button>
          </div>
        ) : videos.length === 0 ? (
          <div className="text-center py-20 text-zinc-500">No videos found. Try another category or add videos via Telegram sync in Admin.</div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4 gap-x-4 gap-y-6">
              {videos.map(v => <VideoCard key={v._id} video={v} />)}
            </div>
            <div ref={ref as any} className="h-10 flex items-center justify-center mt-8">
              {loading && <div className="w-6 h-6 border-2 border-zinc-300 border-t-black dark:border-zinc-700 dark:border-t-white rounded-full animate-spin" />}
              {!hasMore && videos.length>0 && <span className="text-sm text-zinc-500">You've reached the end</span>}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
