import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { videoApi } from '../services/api';
import type { Video } from '../types';
import VideoCard from '../components/VideoCard';

export default function SearchResults() {
  const [params] = useSearchParams();
  const q = params.get('q') || '';
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!q) { setVideos([]); return; }
    const fetchSearch = async () => {
      setLoading(true);
      try {
        const { data } = await videoApi.search(q, { limit: 24 });
        setVideos(data.videos || data.data || data || []);
      } catch {
        // fallback to general list with search param
        try {
          const { data } = await videoApi.getAll({ search: q, limit: 24 });
          setVideos(data.videos || data.data || []);
        } catch {
          setVideos([]);
        }
      }
      setLoading(false);
    };
    fetchSearch();
  }, [q]);

  return (
    <div className="p-4 md:p-6 max-w-[1800px] mx-auto">
      <h1 className="text-lg mb-4">Search results for <span className="font-bold">"{q}"</span></h1>
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({length:8}).map((_,i)=><div key={i} className="aspect-video bg-zinc-800 rounded-xl animate-pulse"/>)}
        </div>
      ) : videos.length===0 ? (
        <div className="text-center py-20 text-zinc-500">No results for "{q}"</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-6">
          {videos.map(v=> <VideoCard key={v._id} video={v} />)}
        </div>
      )}
    </div>
  );
}
