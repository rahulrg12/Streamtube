import { Link } from 'react-router-dom';

export default function Playlists() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Playlists</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <Link to="/watch-later" className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex gap-4 hover:bg-zinc-50 dark:hover:bg-zinc-900">
          <div className="w-20 h-14 bg-zinc-800 rounded-lg flex items-center justify-center">⏱</div>
          <div><div className="font-medium">Watch Later</div><div className="text-sm text-zinc-500">Private • Videos you saved</div></div>
        </Link>
        <Link to="/history" className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex gap-4 hover:bg-zinc-50 dark:hover:bg-zinc-900">
          <div className="w-20 h-14 bg-zinc-800 rounded-lg flex items-center justify-center">🕘</div>
          <div><div className="font-medium">History</div><div className="text-sm text-zinc-500">Videos you watched</div></div>
        </Link>
      </div>
      <div className="mt-10 text-sm text-zinc-500">Custom playlists coming soon. Backend should implement /api/playlists CRUD.</div>
    </div>
  );
}
