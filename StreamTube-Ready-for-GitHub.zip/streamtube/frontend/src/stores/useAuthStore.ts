import { create } from 'zustand';
import { authApi } from '../services/api';
import type { User } from '../types';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  fetchMe: () => Promise<void>;
  setUser: (u: User | null) => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: JSON.parse(localStorage.getItem('streamtube-user') || 'null'),
  isLoading: false,
  isAuthenticated: !!localStorage.getItem('streamtube-user'),
  error: null,

  setUser: (user) => {
    if (user) localStorage.setItem('streamtube-user', JSON.stringify(user));
    else localStorage.removeItem('streamtube-user');
    set({ user, isAuthenticated: !!user });
  },

  clearError: () => set({ error: null }),

  fetchMe: async () => {
    set({ isLoading: true });
    try {
      const { data } = await authApi.me();
      const user = data.user || data;
      localStorage.setItem('streamtube-user', JSON.stringify(user));
      set({ user, isAuthenticated: true, isLoading: false });
    } catch {
      localStorage.removeItem('streamtube-user');
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const { data } = await authApi.login({ email, password });
      const user = data.user || data;
      localStorage.setItem('streamtube-user', JSON.stringify(user));
      set({ user, isAuthenticated: true, isLoading: false });
    } catch (e: any) {
      const msg = e.response?.data?.message || e.message || 'Login failed';
      set({ error: msg, isLoading: false });
      throw new Error(msg);
    }
  },

  register: async (username, email, password) => {
    set({ isLoading: true, error: null });
    try {
      const { data } = await authApi.register({ username, email, password });
      const user = data.user || data;
      if (user && user._id) {
        localStorage.setItem('streamtube-user', JSON.stringify(user));
        set({ user, isAuthenticated: true, isLoading: false });
      } else {
        set({ isLoading: false });
      }
    } catch (e: any) {
      const msg = e.response?.data?.message || e.message || 'Registration failed';
      set({ error: msg, isLoading: false });
      throw new Error(msg);
    }
  },

  logout: async () => {
    try {
      await authApi.logout();
    } catch {}
    localStorage.removeItem('streamtube-user');
    set({ user: null, isAuthenticated: false });
  },
}));
