# StreamTube Frontend

React + TypeScript + Vite + Tailwind dark theme YouTube clone.

## Setup

```bash
cp .env.example .env
npm install
npm run dev
```

Runs on http://localhost:3000, proxies /api to VITE_API_URL.

## Features Implemented

- Navbar with search, theme toggle, auth menu, responsive
- Sidebar collapsible, categories
- VideoCard lazy thumbnail, duration badge, IntersectionObserver
- VideoPlayer with hls.js fallback, custom controls, keyboard shortcuts:
  Space/K play, M mute, F fullscreen, arrows seek/volume, touch swipe
- VideoInfo likes/dislikes/subscribe/share/watch-later
- Comments add/edit/delete
- Home infinite scroll via IntersectionObserver /api/videos?category&sort&page
- Watch page with player + info + comments + related
- Auth pages login/register with withCredentials axios
- History / Watch Later with real API calls
- SearchResults /api/videos/search?q=
- AdminDashboard:
  - Telegram config form: botToken, channelId, apiId, apiHash, sessionString
  - Test connection button -> POST /api/admin/telegram/test
  - Sync history (MTProto) -> POST /api/admin/telegram/sync/history
  - Sync new -> POST /api/admin/telegram/sync/new
  - Logs table, video management delete
  - Honest warning: Bot API cannot fetch history; needs MTProto api_id/hash + user session

## Backend Contract

Streaming MUST support Range headers:

```
GET /api/videos/:id/stream
Range: bytes=0-1024000
=> 206 Partial Content
   Content-Range: bytes 0-1024000/total
   Accept-Ranges: bytes
```

HLS optional:

```
GET /api/videos/:id/hls/index.m3u8
-> m3u8 playlist
```

Auth uses httpOnly cookie with withCredentials.

## Env

VITE_API_URL=http://localhost:5000
