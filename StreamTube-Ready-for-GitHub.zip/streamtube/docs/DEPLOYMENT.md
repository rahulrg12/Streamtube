# StreamTube Production Deployment

## Architecture
```
User -> CDN Cloudflare -> Frontend Vercel (streamtube.example.com)
                     -> API Render/Railway (api.streamtube.example.com) -> Postgres Managed
                                                            -> Telegram Bot API (telegram.org)
                                                            -> MTProto history job
                                                            -> S3 / R2 / DO Spaces (if STORAGE_TYPE=s3) -> CDN
```

Separate frontend/backend domains, HTTPS mandatory.

## Env Vars Production

Backend required:
- DATABASE_URL postgres://...?sslmode=require
- SESSION_SECRET random 64 char
- NODE_ENV production
- PORT 10000 (Render provides)
- FRONTEND_URL https://streamtube.example.com
- TELEGRAM_BOT_TOKEN
- TELEGRAM_CHANNEL_ID -100...
- API_ID, API_HASH, SESSION_STRING (MTProto)
- STORAGE_TYPE s3|telegram (s3 recommended prod)
- S3_ENDPOINT, S3_REGION, S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_PUBLIC_URL (if s3)
- CDN_URL optional
- COOKIE_SECURE true
- COOKIE_DOMAIN .example.com
- COOKIE_SAMESITE Lax or None

Frontend Vercel:
- VITE_API_URL=https://api.streamtube.example.com
- VITE_CDN_URL=https://cdn.example.com

Never expose secrets to frontend.

## HTTPS & Secure Cookies
```ts
cors({ origin: FRONTEND_URL, credentials: true })
cookie: {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  domain: process.env.COOKIE_DOMAIN,
  maxAge: 7*24*60*60*1000
}
```
- SameSite=None requires Secure true
- Helmet HSTS

## Deploy Backend

### Render
1. New Web Service -> GitHub repo
2. Root backend, Build npm install && npm run build, Start npm start
3. Env vars table
4. Add Postgres addon
5. Migration: Render Shell npm run db:migrate
Health: /api/health

### Railway
railway init, railway add -d postgres, railway variables set, railway up

### DigitalOcean App Platform
Create App GitHub, components: backend Node, frontend static, add Managed Postgres, add env encrypted, domains.

### Self-hosted Docker VPS
```bash
git clone repo
cp .env.example .env # edit prod
docker-compose up -d --build
# setup nginx + certbot
```
Nginx proxy proxy_pass http://localhost:4000 + ssl certs.

## Deploy Frontend

### Vercel
Import frontend dir, framework Vite, build npm run build, output dist, env VITE_API_URL, add domain. Backend FRONTEND_URL must match exactly.

## Storage Strategy

### A Telegram Proxy (default dev)
Pros free, Cons 2GB limit, no native Range, slow seek, rate limit.
Proxies getFile URL, fakes Range by downloading chunk. Not recommended prod.

### B S3 Recommended prod
Upload -> Telegram AND S3 parallel. Streaming via S3 presigned URL with Range, native seek, no 2GB limit. CDN front. CORS allow GET HEAD.

Config STORAGE_TYPE=s3 + S3_*

### C Local filesystem
Single VPS dev only.

## CDN
Cloudflare free in front of api + S3. Cache thumbnails not stream or with Range. Cache-Control public max-age 31536000 immutable for S3 objects. Frontend Vercel auto CDN.

## Database Prod
Managed Postgres: Render Postgres, Neon, Supabase, DO Managed. Enable connection pooling PgBouncer. Backups daily. sslmode=require.

## Honest Limits Prod
- Bot API alone still cannot sync history in prod. Still need MTProto job even prod. Schedule cron daily? Actually historical sync once then Bot webhook for new.
- FloodWait prod many channels may trigger. Queue + delay.
- File size >2GB need local Bot API server https://github.com/tdlib/telegram-bot-api self-hosted, set TELEGRAM_BOT_API_URL env, limit becomes 4GB.

Local Bot API server deploy:
```bash
docker run -d -p 8081:8081 ghcr.io/tdlib/telegram-bot-api:latest --api-id=... --api-hash=...
```

## Security Checklist
- [ ] secrets not in repo
- [ ] SESSION_SECRET 48+ chars
- [ ] COOKIE_SECURE true HSTS
- [ ] CORS exact origin not *
- [ ] Rate limit
- [ ] Helmet
- [ ] Bot webhook secret token validation X-Telegram-Bot-Api-Secret-Token
- [ ] SESSION_STRING protected, rotate if leaked
- [ ] S3 bucket not public write, presigned short 15m
- [ ] DB SSL

## Monitoring
Health endpoint /api/health, pino logs, UptimeRobot, Prometheus if self-hosting.