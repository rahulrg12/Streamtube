# StreamTube Troubleshooting

## 1. Telegram Bot Errors

### Unauthorized token invalid
Cause TOKEN wrong revoked. Fix curl https://api.telegram.org/botTOKEN/getMe should return, regenerate @BotFather /revoke update env restart.

### Chat not found
Cause CHANNEL_ID incorrect or bot not admin. Fix ID numeric -100..., forward to @userinfobot, ensure bot admin with Post Delete rights, curl getChat.

### Forbidden not member or no channel_post
Fix remove re-add bot admin, private channel invite needed.

### File is too big 400
Cause upload >2GB Bot API (4GB local). Fix split compress or local Bot API server or S3 storage.

### getFile file_id invalid
Cause file_id from different bot, bot-specific, expired. Fix re-sync history via MTProto to get fresh file_ids, store file_id + file_unique_id, fallback S3.

## 2. MTProto GramJS Errors

### API_ID_INVALID
Fix ensure integer from my.telegram.org not bot token Number(API_ID).

### API_HASH_INVALID
Fix copy exactly no spaces.

### SESSION_STRING invalid AUTH_KEY_UNREGISTERED
Cause corrupted terminated API_ID changed. Fix regenerate npm run telegram:session ensure trimmed same API_ID/HASH, terminate old sessions Telegram Settings Devices Active sessions.

### FloodWaitError wait X seconds
Fix backend returns 429 retry_after wait, don't loop limit 1000 fast, sleep 1-2s, historical sync once not cron every minute.

### PHONE_NUMBER_INVALID PHONE_CODE_INVALID
Phone must +country, code expires 2min request new, need 2FA password.

### CHANNEL_PRIVATE CHANNEL_INVALID
Cause user account that generated SESSION not member of channel. Fix join channel with that account before sync.

## 3. Database Errors

### ECONNREFUSED 127.0.0.1:5432
Postgres not running docker-compose up -d postgres or sudo service postgresql start.

### database streamtube does not exist
docker exec psql CREATE DATABASE or createdb.

### relation videos does not exist
Schema not migrated psql $DATABASE_URL -f database/schema.sql or npm run db:migrate

### too many clients
Pool leak reduce max new Pool({max:10}) PgBouncer prod.

## 4. Streaming Range Errors

### No video with supported format
Backend returned JSON error not binary missing file. Check /api/videos/:id/stream direct, logs file_id invalid, switch S3.

### 416 Range Not Satisfiable
Range beyond file size. Validate parsing.

```ts
const range = req.headers.range;
const [startStr,endStr]=range.replace(/bytes=/,'').split('-');
let start=parseInt(startStr,10); let end=endStr?parseInt(endStr,10):fileSize-1;
if(start>=fileSize||end>=fileSize) return 416
```

### Seeking slow high memory telegram mode
Cause proxy no Range native buffering. Fix STORAGE_TYPE=s3 with presigned Range or cache temp file.

### CORS error video tag
Fix cors origin FRONTEND_URL credentials true include Access-Control-Allow-Headers Range. axios.defaults.withCredentials true.

## 5. Auth Errors

### 401 after login
Cookie sid httpOnly not sent fetch without credentials include, SESSION_SECRET changed invalidates JWT, Cookie Secure true on http localhost not set Set COOKIE_SECURE=false dev.

### 403 Admin only when I am admin
First user admin others user. Fix psql UPDATE users SET role='admin' WHERE email.

### JWT TokenExpiredError
Token expiry 7d re-login server time correct.

## 6. Env Setup Errors

### Missing env var TELEGRAM_BOT_TOKEN
.env not loaded backend looks backend/.env then ../.env create from .env.example dotenv before imports.

### SESSION_STRING undefined but history sync requested
Expected error fill API_ID API_HASH SESSION_STRING or use bot sync new messages only.

### Secrets committed
Fix NOW revoke bot @BotFather, terminate Telegram sessions Privacy Active Sessions, regenerate app my.telegram.org delete create new, rotate SESSION_SECRET DATABASE_URL S3 keys, purge git history git filter-repo.

Prevent .gitignore .env *.session git-secrets hook.

## 7. Docker Compose

### postgres exited role does not exist
Volume leftover different creds docker-compose down -v destroys data then up.

### backend cannot connect postgres ENOTFOUND postgres
Inside docker DATABASE_URL host postgres not localhost. Compose overrides DATABASE_URL postgres://...@postgres:5432... host localhost when outside.

### Port already in use 4000 5173
lsof -i :4000 kill or change PORT env/compose.

## 8. S3 Storage

### NoSuchBucket AccessDenied
Bucket name endpoint wrong R2 needs auto region keys wrong. Check S3_* env policy GetObject PutObject.

### InvalidAccessKeyId
Keys no spaces trim.

### CORS S3 not Range
Add bucket CORS AllowedHeaders *, Methods GET HEAD, Origins https://..., ExposeHeaders Content-Range Content-Length Accept-Ranges

## 9. Rate Limit Performance

### 429 Too Many Requests stream or login
express-rate-limit triggered increase limit prod streaming should NOT rate-limit aggressive skip stream route.

### High latency Telegram proxy
Switch S3 CDN caching temp file /tmp local cache.

## Checklist Before Help

Include NODE_ENV STORAGE_TYPE error log pino health output getChat verified MTProto session user member of channel migration status dt, whether history needs MTProto vs new messages Bot API, DATABASE_URL reachable.

Honest reminder: If trying to fetch old videos with only Bot API that never works need MTProto.