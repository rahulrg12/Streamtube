# StreamTube API Documentation

Base URL:
- Development: `http://localhost:4000`
- Production: `https://api.streamtube.example.com`

All endpoints prefixed with `/api`. JSON content type unless streaming.

**Authentication:** Session cookie `sid` (httpOnly) + JWT `Authorization: Bearer <token>` fallback.

**16 Endpoints total.**

---

## Auth

### 1. POST /api/auth/register
Register new user. First user becomes `admin` if no admin exists, otherwise `user`.

**Request**
```json
{
  "email": "alice@example.com",
  "password": "Str0ng!Pass123",
  "username": "alice"
}
```

**Response 201**
```json
{
  "id": "uuid",
  "email": "alice@example.com",
  "username": "alice",
  "role": "user",
  "created_at": "2024-01-01T00:00:00Z"
}
```

**Errors:** 400 invalid, 409 email exists

---

### 2. POST /api/auth/login
**Request**
```json
{
  "email": "alice@example.com",
  "password": "Str0ng!Pass123"
}
```

**Response 200** Sets `sid` cookie
```json
{
  "token": "eyJhbG...",
  "user": { "id": "uuid", "email": "...", "role": "user" }
}
```

### 3. POST /api/auth/logout
Clears session. Requires auth.

**Response 200**
```json
{ "message": "Logged out" }
```

### 4. GET /api/auth/me
Return current user. Auth required.

### 5. GET /api/videos
List videos with pagination, search, filters.

Query params: page, limit, q, channel_id, sort=newest|oldest|popular|size, mime

**Response 200**
```json
{
  "videos": [
    {
      "id": "uuid",
      "title": "Big Buck Bunny",
      "file_name": "big_buck.mp4",
      "mime_type": "video/mp4",
      "file_size": 12457890,
      "duration": 596,
      "width": 1920,
      "height": 1080,
      "thumbnail_url": "/api/videos/uuid/thumbnail",
      "stream_url": "/api/videos/uuid/stream",
      "views": 123,
      "created_at": "2024-01-02T10:00:00Z"
    }
  ],
  "pagination": { "page": 1, "limit": 20, "total": 156, "total_pages": 8 }
}
```

### 6. GET /api/videos/:id
Get single video metadata.

### 7. GET /api/videos/:id/stream
Core feature. Supports HTTP Range.

- Range: bytes=0-1023
- Returns 200 or 206 Partial Content with Content-Range
- Streaming modes:
  - telegram (default): Proxies from Telegram getFile. No native Range, backend fakes it.
  - s3: Native Range support via S3 GetObject with Range header, fastest
  - local: fs.createReadStream with start/end

Example curl:
```bash
curl -v -H "Range: bytes=0-999999" http://localhost:4000/api/videos/uuid/stream --output chunk.mp4
```

Works with <video> tag natively.

### 8. GET /api/videos/:id/download
Forces download attachment.

### 9. POST /api/videos/sync
Trigger Bot API sync for NEW messages only. Admin only.

**Honest limit:** This does NOT fetch history. Only new messages after bot became admin.

**Response 200**
```json
{ "scanned": 20, "imported": 5, "skipped": 15 }
```

### 10. POST /api/videos/upload
Upload local file -> send to Telegram channel. Admin, multipart/form-data.

Fields: file (max 2GB), title, description, channel_id

### 11. DELETE /api/videos/:id
Delete record, optional purge. Admin only.

### 12. PATCH /api/videos/:id
Update metadata title/description/is_public. Admin only.

### 13. GET /api/channels
List configured Telegram channels. Admin only.

### 14. POST /api/channels/sync/history
Historical sync via MTProto. Admin.

**Why MTProto?** Bot API has no method to fetch channel history. Only user accounts via MTProto can. See TELEGRAM.md.

Request:
```json
{
  "telegram_channel_id": "-1001234567890",
  "limit": 500,
  "offset_id": 0
}
```

Response 202 or 200:
```json
{ "scanned": 500, "imported": 120, "flood_wait_seconds": 0 }
```

FloodWait returns 429.

### 15. GET /api/admin/stats
Admin stats.

Response includes telegram_limits explaining bot cannot get history.

### 16. GET /api/health
Public health check.

```json
{
  "status": "ok",
  "database": "connected",
  "telegram_bot": "configured",
  "mtproto": "configured"
}
```

---

## Rate Limit Headers
X-RateLimit-Limit, Remaining, Reset

## Errors
Standard: error, message, details, retry_after for FloodWait

## Why Bot API Historical Sync NOT Supported
Bottom line: Bot API has no getChatHistory. Only MTProto has messages.getHistory. Docs/TELEGRAM.md details.