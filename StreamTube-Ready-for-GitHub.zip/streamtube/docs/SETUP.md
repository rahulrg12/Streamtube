# StreamTube Local Setup - Step by Step

## 0. Prerequisites
- Node.js 18+ (20 recommended)
- Docker & Docker Compose
- Telegram account
- Git

## 1. Clone & Install
```bash
git clone https://github.com/your-org/streamtube.git
cd streamtube
npm install
```

## 2. Postgres Setup

### Option A Docker (recommended)
```bash
docker-compose up -d postgres
docker exec -it streamtube-postgres psql -U postgres -c "CREATE DATABASE streamtube;"
```

Default:
- Host localhost:5432
- User postgres / pass postgres / DB streamtube
- URL postgres://postgres:postgres@localhost:5432/streamtube

### Option B Local
```bash
sudo apt install postgresql
sudo -u postgres psql
CREATE DATABASE streamtube;
```

### Run migrations
```bash
psql $DATABASE_URL -f database/schema.sql
# or
cd backend && npm run db:migrate
```

## 3. Telegram Bot Creation
1. Chat @BotFather in Telegram
2. /newbot -> name `StreamTubeBot`, username `my_streamtube_bot`
3. Save token `123456:ABC-DEF...` -> TELEGRAM_BOT_TOKEN

## 4. Telegram Channel Setup
1. Create Channel (not group)
2. Add bot as Administrator (Channel Settings -> Administrators -> Add -> search bot username -> give Post, Delete rights)
3. Get TELEGRAM_CHANNEL_ID numeric -100...
   - Forward channel message to @userinfobot -> returns ID
4. Verify:
```bash
curl https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/getChat?chat_id=$TELEGRAM_CHANNEL_ID
```

## 5. MTProto Setup - REQUIRED for historical sync

Bot API CANNOT get history. For old videos need MTProto.

### 5a. Get API_ID and API_HASH
1. https://my.telegram.org login with phone
2. API development tools -> Create app
   - App title StreamTube, short name streamtube, Platform Other
3. Save API_ID (e.g. 1234567) and API_HASH

### 5b. Generate SESSION_STRING via script

Env file backend/.env must have API_ID, API_HASH

Install:
```bash
cd backend
npm install
```

Run:
```bash
npm run telegram:session
```

Prompts:
- Phone with country code
- Code from Telegram app
- 2FA password if enabled

Output:
```
SESSION_STRING: 1AgA...
```

Save to .env as SESSION_STRING. Secret like password!

Script at backend/scripts/generate-session.ts uses GramJS TelegramClient + StringSession.

If FloodWaitError, wait seconds.

## 6. Environment

Create backend/.env (see root .env.example):

```
DATABASE_URL=postgres://postgres:postgres@localhost:5432/streamtube
SESSION_SECRET=openssl_rand_base64_32_output
NODE_ENV=development
PORT=4000
FRONTEND_URL=http://localhost:5173

TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_CHANNEL_ID=-1001234567890

API_ID=1234567
API_HASH=abcdef...
SESSION_STRING=1AgA...

STORAGE_TYPE=telegram
```

Generate SESSION_SECRET:
```bash
openssl rand -base64 32
```

Frontend frontend/.env:
```
VITE_API_URL=http://localhost:4000
```

## 7. Run
```bash
docker-compose up --build
# or separate terminals
cd backend && npm run dev   # http://localhost:4000
cd frontend && npm run dev  # http://localhost:5173
```

## 8. Initial Admin & Sync
Register first user becomes admin:
```bash
curl -X POST http://localhost:4000/api/auth/register -H "Content-Type: application/json" -d '{"email":"admin@example.com","password":"Admin123!","username":"admin"}'
curl -X POST http://localhost:4000/api/auth/login -H "Content-Type: application/json" -d '{"email":"admin@example.com","password":"Admin123!"}' -c cookies.txt
curl -X POST http://localhost:4000/api/channels/sync/history -H "Content-Type: application/json" -b cookies.txt -d '{"telegram_channel_id":"-1001234567890","limit":200}'
curl http://localhost:4000/api/videos -b cookies.txt | jq
```

## Checklist
- Postgres running + schema loaded
- Bot created and admin in channel
- CHANNEL_ID numeric -100
- API_ID/HASH from my.telegram.org
- SESSION_STRING generated
- SESSION_SECRET random 32+ chars
- First user admin
- History sync tested
- Stream Range works: curl -H "Range: bytes=0-1000" ...