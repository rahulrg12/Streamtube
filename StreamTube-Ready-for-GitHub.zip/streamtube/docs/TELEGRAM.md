# Telegram Integration - REAL Limitations

## TL;DR Summary

| Feature | Bot API | MTProto (user) | Notes |
|---------|---------|----------------|-------|
| Receive NEW channel posts after bot admin | Yes | Yes | Bot gets channel_post updates |
| Get HISTORICAL channel messages | NO | Yes via messages.getHistory | Bot API has no method |
| Download file via getFile+file_path | Yes | Yes better | Bot 2GB limit (4GB local API) |
| Upload to channel | Yes | Yes | 2GB Bot limit |
| Delete message | Yes if admin | Yes | |
| Range / seeking | NO Bot server doesn't support Range | Custom chunk | We fake Range |
| Rate limits | Medium 429 | Heavy FloodWait seconds to hours | |
| Need api_id/hash | No | Yes my.telegram.org | |
| Need session string | No | Yes sensitive password equivalent | |

**Conclusion: Historical sync via Bot API alone NOT supported. Ever.**

## 1. Bot API - What It Really Is

HTTP layer: https://api.telegram.org/botTOKEN/method, token from @BotFather.

### What Bot CAN
- getMe, getUpdates/Webhook receives new updates only after bot added, channel_post when someone posts where bot is admin
- sendVideo/sendDocument upload returns file_id
- getFile file_id -> file_path like videos/file_123.mp4
- Download https://api.telegram.org/file/botTOKEN/file_path
- deleteMessage

### What Bot CANNOT
**Critical: NO getChatHistory, getChannelHistory, getMessages for bots.**

- Bot CANNOT call messages.getHistory. Method doesn't exist in Bot API.
- Bot CANNOT iterate old channel posts. getUpdates only returns messages after polling started with offset after last acknowledged. Old gone.
- Bot CANNOT search, cannot get file by message_id without file_id stored.

So 1000 existing videos in channel, Bot API never sees them. Need MTProto.

### File size limit
- Default api.telegram.org 2GB max upload/download. >2GB 400 file is too big
- Local Bot API server self-hosted https://github.com/tdlib/telegram-bot-api 4GB max

### getFile flow
```ts
const file = await bot.getFile(fileId); // {file_path}
const url = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
const response = await fetch(url);
```

## 2. MTProto - Why and How

MTProto native protocol for clients. Libraries telegram (GramJS JS), Telethon Python.

Only MTProto can call channels.getHistory / messages.getHistory.

### What you need
- API_ID numeric, API_HASH string, SESSION_STRING StringSession long base64

### How to get API_ID/HASH
https://my.telegram.org login phone -> API dev tools -> Create app title StreamTube short name streamtube Platform Other -> save api_id and api_hash.

### How to generate SESSION_STRING

Script backend/scripts/generate-session.ts using GramJS TelegramClient StringSession.

```
API_ID: 1234567
API_HASH: abc...
Phone: +1234567890
Code: 12345
2FA Password if enabled
Session String: 1AgA... save to .env
```

Security highest secret = password. Revoke via Telegram Settings -> Active sessions.

### Historical sync sketch
```ts
import { TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions";
import { Api } from "telegram";
const client = new TelegramClient(new StringSession(SESSION_STRING), API_ID, API_HASH, {});
await client.connect();
const channel = await client.getEntity(TELEGRAM_CHANNEL_ID);
let offsetId=0;
while(true){
  const history = await client.invoke(new Api.messages.GetHistory({peer:channel, offsetId, limit:100}));
  const messages = history.messages as any[];
  if(!messages.length) break;
  for(const msg of messages){ if(msg.media?.document) /* save to DB */ }
  offsetId = messages[messages.length-1].id;
  if(messages.length<100) break;
  await new Promise(r=>setTimeout(r,1000));
}
```

### FloodWait
MTProto heavy rate limits. When too fast returns FloodWaitError seconds you must wait, can be 10s to hours. Backend catches returns 429 retryAfter. Mitigation sleep 1-2 sec, limit 100 per call, queue, sync once then Bot updates.

## 3. Streaming: Proxy vs Storage Adapter

Problem Telegram Bot API file download URL does NOT support HTTP Range. Must download whole then slice. Seeking terrible.

Adapter pattern STORAGE_TYPE:
- telegram default: getFile -> file_path -> fetch url. If Range requested, download chunk manually skip bytes. Memory heavy, slow. Better temp file cache.
- s3 prod: S3 GetObject with Range: bytes=start-end, native Range, fast seek. Or 302 redirect presigned URL.
- local: fs.createReadStream path {start,end} native.

Fallback: If Telegram fails, try S3 if exists, else local cache, else 404.

## 4. Credentials
- TELEGRAM_BOT_TOKEN @BotFather, secret high, Bot API new/upload/getFile
- TELEGRAM_CHANNEL_ID @userinfobot -100, not secret but not public
- API_ID my.telegram.org numeric not secret but app tied
- API_HASH my.telegram.org secret
- SESSION_STRING generate script, highest secret = password
- DATABASE_URL Postgres secret
- SESSION_SECRET random 64 char secret JWT
- STORAGE_TYPE telegram|s3|local not secret
- S3_* from AWS/R2/DO dashboard secret for keys

SESSION_STRING allows login as you, read all chats. Rotate terminating sessions.

## 5. Common Mistakes
- Bot added but no videos appear -> Bot cannot fetch history, need MTProto POST /api/channels/sync/history
- File >2GB -> local Bot API server or S3
- FloodWait 300s -> scraped too fast MTProto wait backoff
- getFile 404 file_path -> file_id from different bot, file_ids bot-specific, re-sync via MTProto
- Stream slow seeking -> using telegram proxy, switch S3
- Bot no updates -> not admin, getUpdates offset, check privacy groups need privacy disabled

## 6. Local Bot API Server Optional 4GB

https://github.com/tdlib/telegram-bot-api

```bash
docker run -d -p 8081:8081 ghcr.io/tdlib/telegram-bot-api:latest
```
Set env TELEGRAM_BOT_API_URL=http://localhost:8081, backend respects if set.

Advantages faster, 4GB, local storage. Disadvantage manage.

## 7. Decision Tree
Need import OLD videos? YES -> MTProto API_ID/HASH/SESSION_STRING + /api/channels/sync/history, NO only new -> Bot API enough
Need fast seeking >2GB? Use S3 STORAGE_TYPE=s3
Private channel? user must be member.

## Final Statement
StreamTube honest: historical sync via Bot API alone NOT supported. Any claim bot can fetch channel history via Bot API is wrong. Use MTProto. Documented everywhere README, SETUP, API, DEPLOYMENT.